import React, { useState, useRef, useCallback, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Scissors, Volume2, Zap, Clock, Upload, RotateCcw, AlertTriangle, CheckCircle2, Film, Lock, Star, Copy, TrendingUp, Image as ImageIcon, Lightbulb, Repeat, HelpCircle, LayoutDashboard, History as HistoryIcon, Settings as SettingsIcon, Search, Bell, Sun, Moon, ChevronLeft, ChevronRight, Sparkles, RefreshCw, Tag } from "lucide-react";

// ---- Tunable benchmarks ----
// ---- Tunable benchmarks (mutable so Settings can adjust them live) ----
// ---- Tunable benchmarks ----
// These are DEFAULTS only. Actual values used during analysis are threaded
// through as function parameters (see runAnalysis / DEFAULT_SETTINGS) rather
// than mutated as module-level globals, so concurrent/overlapping analysis
// runs can't clobber each other's configuration.
const MAX_SAMPLES = 320;
const IDEAL_MIN_SHOT = 0.4;
const RMS_WINDOW = 0.5;
const SILENCE_MIN_DUR = 0.3;
const IDEAL_RATIO = 9 / 16;

const DEFAULT_SETTINGS = { sceneThreshold: 16, idealMaxShot: 3.0, hookWindow: 1.5, silenceDb: -40, rmsJumpDb: 8 };

// Commonly-recommended starting points per platform, not scientifically
// derived per-platform benchmarks — presented to the user as such.
const PLATFORM_PRESETS = {
  tiktok: { label: "TikTok", values: { sceneThreshold: 16, idealMaxShot: 2.5, hookWindow: 1.0, silenceDb: -40, rmsJumpDb: 8 } },
  shorts: { label: "YouTube Shorts", values: { sceneThreshold: 16, idealMaxShot: 3.0, hookWindow: 1.5, silenceDb: -40, rmsJumpDb: 8 } },
  reels: { label: "Instagram Reels", values: { sceneThreshold: 16, idealMaxShot: 2.8, hookWindow: 1.2, silenceDb: -38, rmsJumpDb: 7 } },
};

// Adjusted pacing expectations by content type — same honest framing as the
// platform presets: reasonable starting points based on how each format
// typically edits, not a scientifically validated rule set. A cinematic
// video and a meme clip shouldn't be judged by the same shot-length bar.
const CONTENT_TYPE_PRESETS = {
  talking_head: { label: "Talking Head", values: { idealMaxShot: 4.0, hookWindow: 2.0 } },
  vlog: { label: "Vlog", values: { idealMaxShot: 3.5, hookWindow: 1.8 } },
  gaming: { label: "Gaming", values: { idealMaxShot: 2.5, hookWindow: 1.2 } },
  meme_comedy: { label: "Meme / Comedy", values: { idealMaxShot: 2.0, hookWindow: 0.8 } },
  educational: { label: "Educational", values: { idealMaxShot: 4.5, hookWindow: 2.2 } },
  documentary: { label: "Documentary", values: { idealMaxShot: 5.0, hookWindow: 2.5 } },
  product: { label: "Product Video", values: { idealMaxShot: 3.0, hookWindow: 1.5 } },
  storytelling: { label: "Storytelling", values: { idealMaxShot: 3.5, hookWindow: 1.5 } },
  cinematic: { label: "Cinematic", values: { idealMaxShot: 6.0, hookWindow: 3.0 } },
};

function matchingPreset(settings) {
  for (const [key, preset] of Object.entries(PLATFORM_PRESETS)) {
    if (Object.keys(preset.values).every((k) => preset.values[k] === settings[k])) return key;
  }
  return null;
}

// Approximate safe zones as percentages of a standard 1080×1920 vertical
// canvas, sourced from commonly-cited third-party creator guides — NOT
// pulled from TikTok/Meta/YouTube's own official documentation, which isn't
// published as exact pixel specs. Actual UI varies by device, app version,
// and whether the post is organic or an ad. Treat these as a starting
// approximation to visually sanity-check against, not a guarantee.
const SAFE_ZONES = {
  tiktok: { label: "TikTok", top: 10, bottom: 18, right: 14 },
  reels: { label: "Instagram Reels", top: 13, bottom: 21, right: 14 },
  shorts: { label: "YouTube Shorts", top: 10, bottom: 21, right: 5 },
};

const DARK = {
  mode: "dark",
  bgGradA: "#1B1330", bgGradB: "#120E1A",
  panel: "#1D1730", panelAlt: "#17122A", sidebarBg: "#150F24", topbarBg: "#180F2A",
  panelBorder: "#332B54", text: "#F3EFFF", muted: "#9A8FC2", inputBg: "#140F24", rowAlt: "#17122A",
  violet: "#8B5CF6", cyan: "#22D3EE", amber: "#F5A623", red: "#F4506B", green: "#3DDC97",
};
const LIGHT = {
  mode: "light",
  bgGradA: "#F3EFFF", bgGradB: "#FBFAFF",
  panel: "#FFFFFF", panelAlt: "#F6F3FD", sidebarBg: "#FFFFFF", topbarBg: "#FFFFFF",
  panelBorder: "#E3DCF5", text: "#241C3D", muted: "#7A7096", inputBg: "#F6F3FD", rowAlt: "#F6F3FD",
  violet: "#7C3AED", cyan: "#0891B2", amber: "#D97706", red: "#DC2626", green: "#059669",
};
let COLORS = { ...DARK };

function rmsToDb(rms) { return rms <= 0.0000001 ? -100 : 20 * Math.log10(rms); }
function fmtTime(t) { return `${t.toFixed(2)}s`; }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// ---- Safe storage wrapper: falls back to localStorage if window.storage is unavailable ----
const LS_PREFIX = "cutscope_ls_";
function lsKey(key, shared) { return `${LS_PREFIX}${shared ? "shared_" : "priv_"}${key}`; }

const safeStorage = {
  async get(key, shared = false) {
    try {
      if (window.storage && typeof window.storage.get === "function") {
        return await window.storage.get(key, shared);
      }
      throw new Error("window.storage unavailable");
    } catch (e) {
      try {
        const raw = window.localStorage.getItem(lsKey(key, shared));
        return raw === null ? null : { key, value: raw, shared };
      } catch (e2) {
        return null; // localStorage also unavailable (e.g. private mode) — fail soft
      }
    }
  },
  async set(key, value, shared = false) {
    try {
      if (window.storage && typeof window.storage.set === "function") {
        return await window.storage.set(key, value, shared);
      }
      throw new Error("window.storage unavailable");
    } catch (e) {
      try {
        window.localStorage.setItem(lsKey(key, shared), value);
        return { key, value, shared };
      } catch (e2) {
        return null;
      }
    }
  },
  async delete(key, shared = false) {
    try {
      if (window.storage && typeof window.storage.delete === "function") {
        return await window.storage.delete(key, shared);
      }
      throw new Error("window.storage unavailable");
    } catch (e) {
      try {
        window.localStorage.removeItem(lsKey(key, shared));
        return { key, deleted: true, shared };
      } catch (e2) {
        return null;
      }
    }
  },
};

// Lightweight FNV-1a hash for environments without crypto.subtle (fallback only)
function fnv1aHex(bytes) {
  let hash = 0x811c9dc5;
  for (let i = 0; i < bytes.length; i++) {
    hash ^= bytes[i];
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

// Memory-efficient file fingerprint: hashes size/lastModified + small head/tail
// slices instead of the whole file, so large videos don't get fully buffered
// into memory just for a duplicate-detection key. Uses SHA-256 on the sampled
// bytes when Web Crypto is available (secure context), otherwise falls back
// to a fast non-cryptographic hash so the feature degrades instead of crashing.
async function hashFile(file) {
  const SAMPLE_BYTES = 262144; // 256KB from each end
  try {
    const headBlob = file.slice(0, Math.min(SAMPLE_BYTES, file.size));
    const tailStart = Math.max(0, file.size - SAMPLE_BYTES);
    const tailBlob = file.slice(tailStart, file.size);
    const [headBuf, tailBuf] = await Promise.all([headBlob.arrayBuffer(), tailBlob.arrayBuffer()]);
    const meta = `${file.size}:${file.lastModified}:${file.name}`;
    const metaBytes = new TextEncoder().encode(meta);
    const combined = new Uint8Array(metaBytes.length + headBuf.byteLength + tailBuf.byteLength);
    combined.set(metaBytes, 0);
    combined.set(new Uint8Array(headBuf), metaBytes.length);
    combined.set(new Uint8Array(tailBuf), metaBytes.length + headBuf.byteLength);

    if (window.crypto?.subtle?.digest) {
      const digest = await crypto.subtle.digest("SHA-256", combined.buffer);
      return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
    }
    return fnv1aHex(combined);
  } catch (e) {
    // Absolute last resort: a coarse identity key from metadata alone, so the
    // duplicate check degrades gracefully instead of throwing.
    return `meta:${file.size}:${file.lastModified}:${file.name}`;
  }
}

async function analyzeAudio(file) {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) {
    throw new Error("This browser doesn't support the Web Audio API — try a recent Chrome, Edge, Firefox, or Safari.");
  }
  let ctx = null;
  try {
    const arrayBuffer = await file.arrayBuffer();
    ctx = new AudioCtx();
    let audioBuffer;
    try {
      audioBuffer = await ctx.decodeAudioData(arrayBuffer.slice(0));
    } catch (decodeErr) {
      throw new Error("Couldn't decode audio from this file — the format may be unsupported or the file may be corrupted.");
    }
    const sampleRate = audioBuffer.sampleRate;
    const numChannels = audioBuffer.numberOfChannels;
    const channels = new Array(numChannels);
    for (let c = 0; c < numChannels; c++) channels[c] = audioBuffer.getChannelData(c);
    const length = audioBuffer.length;
    const windowSize = Math.max(1, Math.floor(RMS_WINDOW * sampleRate));
    const windowCount = Math.ceil(length / windowSize);
    const windows = new Array(windowCount);
    let idx = 0;
    for (let start = 0; start < length; start += windowSize) {
      const end = Math.min(start + windowSize, length);
      let sumSq = 0;
      const count = (end - start) * numChannels;
      for (let c = 0; c < numChannels; c++) {
        const data = channels[c];
        for (let i = start; i < end; i++) sumSq += data[i] * data[i];
      }
      const rms = Math.sqrt(sumSq / Math.max(count, 1));
      windows[idx++] = { t: start / sampleRate, db: rmsToDb(rms) };
    }
    windows.length = idx;
    return windows;
  } finally {
    if (ctx) {
      try { await ctx.close(); } catch (closeErr) { /* already closed or unsupported — safe to ignore */ }
    }
  }
}

function detectSilence(windows, silenceDb) {
  const gaps = []; let start = null;
  for (let i = 0; i < windows.length; i++) {
    const isSilent = windows[i].db < silenceDb;
    if (isSilent && start === null) start = windows[i].t;
    if (!isSilent && start !== null) {
      const end = windows[i].t;
      if (end - start >= SILENCE_MIN_DUR) gaps.push({ start, end });
      start = null;
    }
  }
  if (start !== null) {
    const end = windows[windows.length - 1].t + RMS_WINDOW;
    if (end - start >= SILENCE_MIN_DUR) gaps.push({ start, end });
  }
  return gaps;
}

function detectJumps(windows, rmsJumpDb) {
  const jumps = [];
  for (let i = 1; i < windows.length; i++) {
    const delta = Math.abs(windows[i].db - windows[i - 1].db);
    if (delta >= rmsJumpDb && windows[i].db > -80 && windows[i - 1].db > -80) jumps.push({ t: windows[i].t, delta });
  }
  jumps.sort((a, b) => b.delta - a.delta);
  return jumps.slice(0, 5);
}

const SEEK_TIMEOUT_MS = 2500;

// Seeks a <video> to `time` and waits for the 'seeked' event, but never hangs
// forever: if the browser doesn't fire 'seeked' within SEEK_TIMEOUT_MS (can
// happen with some codecs/containers), it resolves anyway so analysis can
// continue with whatever frame is currently painted, instead of freezing.
function seekTo(video, time) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      video.removeEventListener("seeked", onSeeked);
      video.removeEventListener("error", onError);
      clearTimeout(timer);
      resolve();
    };
    const onSeeked = () => finish();
    const onError = () => finish();
    const timer = setTimeout(finish, SEEK_TIMEOUT_MS);
    video.addEventListener("seeked", onSeeked);
    video.addEventListener("error", onError);
    try {
      video.currentTime = time;
    } catch (e) {
      finish();
    }
  });
}

// Builds a small per-region motion grid for the first 0-3s (the "hook").
// Genuinely computed from real pixel differences between sampled frames in
// that window, not a decorative visual — each cell's value is the
// accumulated grayscale delta at that screen region, normalized 0-1.
async function computeHookHeatmap(video, duration, isCancelled) {
  const cols = 8, rows = 14;
  const canvas = document.createElement("canvas");
  canvas.width = cols; canvas.height = rows;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  try {
    const hookEnd = Math.min(3, duration);
    const sampleCount = 10;
    const step = hookEnd / sampleCount;
    let prevGray = null;
    const accum = new Float32Array(cols * rows);
    let maxVal = 0;
    for (let i = 0; i <= sampleCount; i++) {
      if (isCancelled && isCancelled()) return null;
      const t = Math.min(i * step, Math.max(0, duration - 0.02));
      await seekTo(video, t);
      let data;
      try {
        ctx.drawImage(video, 0, 0, cols, rows);
        data = ctx.getImageData(0, 0, cols, rows).data;
      } catch (e) {
        continue; // skip a bad frame rather than failing the whole heatmap
      }
      const gray = new Float32Array(cols * rows);
      for (let p = 0, c = 0; p < data.length; p += 4, c++) gray[c] = (data[p] + data[p + 1] + data[p + 2]) / 3;
      if (prevGray) {
        for (let c = 0; c < gray.length; c++) {
          const diff = Math.abs(gray[c] - prevGray[c]);
          accum[c] += diff;
          if (accum[c] > maxVal) maxVal = accum[c];
        }
      }
      prevGray = gray;
    }
    if (maxVal <= 0) return { cols, rows, cells: Array.from(accum) };
    return { cols, rows, cells: Array.from(accum).map((v) => clamp(v / maxVal, 0, 1)) };
  } finally {
    canvas.width = 0; canvas.height = 0;
  }
}

// isCancelled: () => boolean — lets the caller abort mid-loop if the user
// uploads a new file while this run is still in flight.
async function analyzeCutsAndThumbnail(video, duration, setProgress, sceneThreshold, isCancelled) {
  const canvas = document.createElement("canvas");
  const W = 48, H = 27;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Couldn't get a 2D canvas context in this browser.");

  const sampleCount = Math.min(MAX_SAMPLES, Math.max(20, Math.floor(duration * 8)));
  const step = duration / sampleCount;
  let prevFrame = null;
  const cuts = [];
  const frames = new Array(sampleCount);
  let frameCount = 0;
  let maxDiff = -1, maxDiffTime = Math.min(0.5, duration / 2);

  try {
    for (let i = 0; i < sampleCount; i++) {
      if (isCancelled && isCancelled()) return null;
      const t = Math.min(i * step, Math.max(0, duration - 0.05));
      await seekTo(video, t);
      if (isCancelled && isCancelled()) return null;

      let frame;
      try {
        ctx.drawImage(video, 0, 0, W, H);
        frame = ctx.getImageData(0, 0, W, H).data;
      } catch (drawErr) {
        // A single bad frame shouldn't kill the whole analysis — skip it.
        continue;
      }

      let rSum = 0, gSum = 0, bSum = 0;
      for (let p = 0; p < frame.length; p += 4) { rSum += frame[p]; gSum += frame[p + 1]; bSum += frame[p + 2]; }
      const pixelCount = frame.length / 4;
      const brightness = (rSum + gSum + bSum) / (3 * pixelCount);
      const warmth = (rSum - bSum) / pixelCount;
      frames[frameCount++] = { t, brightness, warmth };

      if (prevFrame) {
        let diffSum = 0;
        for (let p = 0; p < frame.length; p += 4) {
          const g1 = (frame[p] + frame[p + 1] + frame[p + 2]) / 3;
          const g2 = (prevFrame[p] + prevFrame[p + 1] + prevFrame[p + 2]) / 3;
          diffSum += Math.abs(g1 - g2);
        }
        const avgDiff = diffSum / (W * H);
        if (avgDiff > sceneThreshold) cuts.push(t);
        if (avgDiff > maxDiff && t > 0.2) { maxDiff = avgDiff; maxDiffTime = t; }
      }
      prevFrame = frame;
      setProgress(Math.round(((i + 1) / sampleCount) * 90));
    }

    if (isCancelled && isCancelled()) return null;
    frames.length = frameCount;

    // capture higher-res thumbnail at the most dynamic moment
    const thumbCanvas = document.createElement("canvas");
    const tw = 240, th = Math.round(240 * ((video.videoHeight / video.videoWidth) || 1.78));
    thumbCanvas.width = tw; thumbCanvas.height = th;
    const tctx = thumbCanvas.getContext("2d");
    let thumbnailDataUrl = null;
    if (tctx) {
      await seekTo(video, maxDiffTime);
      try {
        tctx.drawImage(video, 0, 0, tw, th);
        thumbnailDataUrl = thumbCanvas.toDataURL("image/jpeg", 0.82);
      } catch (thumbErr) {
        thumbnailDataUrl = null; // non-fatal — report still works without a thumbnail
      }
    }
    setProgress(95);

    // Capture a handful of higher-res frames spread across the video for
    // Claude's vision to look at directly — this is real content the model
    // can see, not something inferred from pixel math.
    const sampleFrames = [];
    if (tctx) {
      const sampleTimes = [
        Math.min(0.5, duration * 0.05),
        duration * 0.33,
        duration * 0.66,
        Math.max(0, duration - 0.5),
      ].filter((t, i, arr) => arr.indexOf(t) === i);
      for (const t of sampleTimes) {
        if (isCancelled && isCancelled()) return null;
        await seekTo(video, t);
        try {
          tctx.drawImage(video, 0, 0, tw, th);
          sampleFrames.push({ t, dataUrl: thumbCanvas.toDataURL("image/jpeg", 0.75) });
        } catch (sampleErr) {
          // skip this frame, non-fatal
        }
      }
    }

    const merged = [];
    for (const c of cuts) if (merged.length === 0 || c - merged[merged.length - 1] > 0.3) merged.push(c);
    return { cuts: merged, thumbnailDataUrl, thumbnailTime: maxDiffTime, frames, sampleFrames };
  } finally {
    // Release canvas backing stores promptly rather than waiting on GC.
    canvas.width = 0; canvas.height = 0;
  }
}

// Single pass over frames (sorted by time, as produced by the analysis loop)
// bucketed into shots by cut boundaries — avoids the previous O(shots × frames)
// filter-per-shot approach.
function buildShots(cuts, duration, frames) {
  const bounds = [0, ...cuts, duration];
  const shots = [];
  let frameIdx = 0;
  const n = frames.length;

  for (let i = 0; i < bounds.length - 1; i++) {
    const start = bounds[i], end = bounds[i + 1];
    if (end - start < 0.05) continue;

    let brightnessSum = 0, warmthSum = 0, count = 0;
    while (frameIdx < n && frames[frameIdx].t < start) frameIdx++;
    let scan = frameIdx;
    while (scan < n && frames[scan].t < end) {
      brightnessSum += frames[scan].brightness;
      warmthSum += frames[scan].warmth;
      count++;
      scan++;
    }
    const brightness = count ? brightnessSum / count : 0;
    const warmth = count ? warmthSum / count : 0;

    shots.push({
      index: shots.length + 1, start, end, length: end - start,
      brightness, warmth,
      lightLabel: brightness > 150 ? "Bright" : brightness > 80 ? "Mid-tone" : "Dark",
      colorLabel: warmth > 8 ? "Warm" : warmth < -8 ? "Cool" : "Neutral",
    });
  }
  return shots;
}

function findAudioPeaks(windows, maxPeaks = 8) {
  const peaks = [];
  for (let i = 1; i < windows.length - 1; i++) {
    if (windows[i].db > windows[i - 1].db && windows[i].db >= windows[i + 1].db && windows[i].db > -30) {
      peaks.push({ t: windows[i].t, db: windows[i].db });
    }
  }
  peaks.sort((a, b) => b.db - a.db);
  return peaks.slice(0, maxPeaks).sort((a, b) => a.t - b.t);
}

function buildReport({ duration, cuts, silenceGaps, jumps, windows, videoWidth, videoHeight, frames, hookWindow, idealMaxShot, hasAudio = true }) {
  const issues = [];
  let hookOk = true;

  if (cuts.length > 0) {
    if (cuts[0] > hookWindow) {
      hookOk = false;
      issues.push({ type: "hook", severity: "high", t: cuts[0],
        problem: `No visual change in the first ${hookWindow}s (first cut at ${fmtTime(cuts[0])}).`,
        why: "Static openings tend to lose viewers before the hook lands — most scroll-past decisions happen in the first second or two.",
        text: `No visual change in the first ${hookWindow}s (first cut at ${fmtTime(cuts[0])}). Static openings tend to lose viewers before the hook lands.` });
    }
  } else {
    hookOk = false;
    issues.push({ type: "hook", severity: "low", t: 0,
      problem: "No distinct cuts detected in the whole video.",
      why: "This reads as one continuous shot — fine for some formats, but short-form platforms generally reward visible movement early.",
      text: "No distinct cuts detected — this reads as one continuous shot." });
  }

  let pacingIssues = 0;
  for (let i = 0; i < cuts.length - 1; i++) {
    const len = cuts[i + 1] - cuts[i];
    if (len > idealMaxShot) {
      pacingIssues++;
      issues.push({ type: "pacing", severity: "medium", t: cuts[i],
        problem: `Shot from ${fmtTime(cuts[i])} to ${fmtTime(cuts[i + 1])} runs ${len.toFixed(2)}s.`,
        why: `${(len - idealMaxShot).toFixed(2)}s past the ${idealMaxShot}s pacing benchmark for this format — longer static shots are where attention typically drops.`,
        text: `Shot from ${fmtTime(cuts[i])} to ${fmtTime(cuts[i + 1])} runs ${len.toFixed(2)}s — ${(len - idealMaxShot).toFixed(2)}s past the ${idealMaxShot}s pacing benchmark.` });
    } else if (len < IDEAL_MIN_SHOT) {
      pacingIssues++;
      issues.push({ type: "pacing", severity: "low", t: cuts[i],
        problem: `Shot from ${fmtTime(cuts[i])} to ${fmtTime(cuts[i + 1])} is only ${len.toFixed(2)}s.`,
        why: "May read as choppy or jarring rather than intentional fast-paced editing.",
        text: `Shot from ${fmtTime(cuts[i])} to ${fmtTime(cuts[i + 1])} is only ${len.toFixed(2)}s — may read as choppy.` });
    }
  }

  for (const gap of silenceGaps) {
    issues.push({ type: "silence", severity: "medium", t: gap.start,
      problem: `Dead air from ${fmtTime(gap.start)} to ${fmtTime(gap.end)} (${(gap.end - gap.start).toFixed(2)}s).`,
      why: "Silence without visual payoff is one of the most common places viewers lose momentum and scroll away.",
      text: `Dead air from ${fmtTime(gap.start)} to ${fmtTime(gap.end)} (${(gap.end - gap.start).toFixed(2)}s) — consider trimming or layering sound.` });
  }
  for (const jump of jumps) {
    issues.push({ type: "audio", severity: "high", t: jump.t,
      problem: `Audio jumps ~${jump.delta.toFixed(1)}dB around ${fmtTime(jump.t)}.`,
      why: "Likely an uneven splice point between source clips — sudden volume changes read as unpolished and make viewers reach for the volume control.",
      text: `Audio jumps ~${jump.delta.toFixed(1)}dB around ${fmtTime(jump.t)} — likely an uneven splice point between clips.` });
  }

  const ratio = videoWidth && videoHeight ? videoWidth / videoHeight : IDEAL_RATIO;
  const ratioDiff = Math.abs(ratio - IDEAL_RATIO);
  const platformScore = clamp(100 - ratioDiff * 400, 0, 100);
  if (platformScore < 85) {
    issues.push({ type: "platform", severity: platformScore < 60 ? "high" : "medium", t: 0,
      problem: `Frame is ${videoWidth}×${videoHeight} (${ratio.toFixed(3)}:1).`,
      why: "Short-form platforms favor 9:16 vertical (0.563:1) — off-ratio videos often get letterboxed or cropped oddly in-feed.",
      text: `Frame is ${videoWidth}×${videoHeight} (${ratio.toFixed(3)}:1) — short-form platforms favor 9:16 vertical (0.563:1). Off-ratio videos often get letterboxed or cropped oddly in-feed.` });
  }

  issues.sort((a, b) => a.t - b.t);

  const categories = [
    { key: "hook", label: "Hook Timing", icon: "Zap", score: hookOk ? 100 : 40 },
    { key: "pacing", label: "Cut pacing", icon: "Scissors", score: clamp(100 - pacingIssues * 18, 0, 100) },
    hasAudio
      ? { key: "silence", label: "Dead air", icon: "Clock", score: clamp(100 - silenceGaps.length * 20, 0, 100) }
      : { key: "silence", label: "Dead air", icon: "Clock", score: null, unavailable: true },
    hasAudio
      ? { key: "audio", label: "Audio consistency", icon: "Volume2", score: clamp(100 - jumps.length * 18, 0, 100) }
      : { key: "audio", label: "Audio consistency", icon: "Volume2", score: null, unavailable: true },
    { key: "platform", label: "Platform fit", icon: "Film", score: Math.round(platformScore) },
  ];

  const scoredCategories = categories.filter((c) => !c.unavailable);
  const score = Math.round(scoredCategories.reduce((s, c) => s + c.score, 0) / scoredCategories.length);

  const suggestions = [];
  const catByKey = Object.fromEntries(categories.map((c) => [c.key, c.score]));
  if (catByKey.hook < 70) {
    suggestions.push({ priority: catByKey.hook < 45 ? "high" : "medium", icon: "Zap",
      action: "Put a cut, camera move, or bold on-screen text in the first 1.5s. Viewers decide to stay or scroll before the first second finishes — a static opening is the single biggest drop-off point." });
  }
  if (catByKey.pacing < 70) {
    suggestions.push({ priority: catByKey.pacing < 45 ? "high" : "medium", icon: "Scissors",
      action: `Trim shots running past ${idealMaxShot}s — split them or add a mid-shot cut/zoom to reset attention. If any shots feel too choppy (under ${IDEAL_MIN_SHOT}s), let them breathe slightly longer.` });
  }
  if (hasAudio && catByKey.silence < 80) {
    suggestions.push({ priority: catByKey.silence < 50 ? "high" : "medium", icon: "Clock",
      action: "Cut dead air wherever the timeline shows it, or lay a low music bed under quiet sections so momentum never fully stops." });
  }
  if (hasAudio && catByKey.audio < 80) {
    suggestions.push({ priority: catByKey.audio < 50 ? "high" : "medium", icon: "Volume2",
      action: "Normalize audio levels across clips before exporting — sudden volume jumps at splice points read as unpolished and make viewers reach for the volume button." });
  }
  if (!hasAudio) {
    suggestions.push({ priority: "medium", icon: "Volume2",
      action: "No audio track was detected in this file. If that's unexpected, check your export settings — most short-form platforms expect sound, even if it's just ambient noise or music." });
  }
  if (catByKey.platform < 90) {
    suggestions.push({ priority: catByKey.platform < 60 ? "high" : "medium", icon: "Film",
      action: "Re-export at a true 9:16 vertical frame. Off-ratio video gets cropped or letterboxed differently across TikTok, Reels, and Shorts, hurting how it displays in-feed." });
  }
  if (suggestions.length === 0) {
    suggestions.push({ priority: "low", icon: "CheckCircle2",
      action: "Technical fundamentals are solid. From here, gains come from creative factors this tool can't measure — story, humor, timing of the punchline, and how well the hook matches what actually happens next." });
  }
  const priorityRank = { high: 0, medium: 1, low: 2 };
  suggestions.sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority]);

  const shots = buildShots(cuts, duration, frames);
  const audioPeaks = findAudioPeaks(windows);
  let dbSum = 0, dbMax = -Infinity, dbMin = Infinity, dbValidCount = 0;
  for (let i = 0; i < windows.length; i++) {
    dbSum += windows[i].db;
    if (windows[i].db > -90) {
      if (windows[i].db > dbMax) dbMax = windows[i].db;
      if (windows[i].db < dbMin) dbMin = windows[i].db;
      dbValidCount++;
    }
  }
  const avgDb = windows.length ? dbSum / windows.length : -100;
  const dynamicRange = dbValidCount ? dbMax - dbMin : 0;
  const silenceTotal = silenceGaps.reduce((s, g) => s + (g.end - g.start), 0);
  const avgBrightness = shots.length ? shots.reduce((s, sh) => s + sh.brightness, 0) / shots.length : 0;
  const warmShots = shots.filter((s) => s.colorLabel === "Warm").length;
  const coolShots = shots.filter((s) => s.colorLabel === "Cool").length;
  const overallTone = warmShots > coolShots ? "Predominantly warm" : coolShots > warmShots ? "Predominantly cool" : "Neutral / balanced";

  const videoInfo = {
    duration, width: videoWidth, height: videoHeight,
    ratio: (videoWidth / videoHeight).toFixed(3),
    aspectLabel: platformScore >= 90 ? "Vertical (9:16) — platform native" : platformScore >= 60 ? "Near-vertical" : "Off-standard for Shorts/Reels",
  };

  const audioInfo = { avgDb, dynamicRange, silenceTotal, peaks: audioPeaks, hasAudio };
  const colorInfo = { avgBrightness, overallTone, warmShots, coolShots, totalShots: shots.length };

  return { issues, score, duration, cutCount: cuts.length, categories, windows, shots, videoInfo, audioInfo, colorInfo, suggestions, silenceGaps, cuts };
}

function scoreTier(score) {
  if (score >= 75) return "Solid";
  if (score >= 45) return "Needs attention";
  return "Weak spot";
}

const ICONS = { Zap, Scissors, Clock, Volume2, Film, CheckCircle2 };
function severityColor(sev) { return sev === "high" ? COLORS.red : sev === "medium" ? COLORS.amber : COLORS.green; }

function Gauge({ score }) {
  const pct = score / 100;
  const angle = -120 + pct * 240;
  const zoneColor = score >= 75 ? COLORS.green : score >= 45 ? COLORS.amber : COLORS.red;
  const circumference = 2 * Math.PI * 70 * (240 / 360);
  return (
    <div style={{ position: "relative", width: 220, height: 170, margin: "0 auto" }}>
      <svg viewBox="0 0 200 160" width="220" height="170">
        <defs>
          <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={COLORS.red} /><stop offset="50%" stopColor={COLORS.amber} /><stop offset="100%" stopColor={COLORS.green} />
          </linearGradient>
          <filter id="glow"><feGaussianBlur stdDeviation="3" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        </defs>
        <path d="M 30 130 A 70 70 0 1 1 170 130" fill="none" stroke={COLORS.panelBorder} strokeWidth="12" strokeLinecap="round" />
        <path d="M 30 130 A 70 70 0 1 1 170 130" fill="none" stroke="url(#gaugeGrad)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${pct * circumference} ${circumference}`} filter="url(#glow)" />
        <g transform={`rotate(${angle} 100 130)`}><line x1="100" y1="130" x2="100" y2="66" stroke={COLORS.text} strokeWidth="3" strokeLinecap="round" filter="url(#glow)" /></g>
        <circle cx="100" cy="130" r="7" fill={COLORS.text} />
      </svg>
      <div style={{ position: "absolute", top: 96, left: 0, right: 0, textAlign: "center" }}>
        <div style={{ fontFamily: "ui-monospace, monospace", fontSize: 26, fontWeight: 800, color: zoneColor, textShadow: `0 0 20px ${zoneColor}66` }}>{scoreTier(score)}</div>
        <div style={{ fontFamily: "ui-monospace, monospace", fontSize: 10, letterSpacing: 3, color: COLORS.muted, textTransform: "uppercase", marginTop: 2 }}>technical execution</div>
      </div>
    </div>
  );
}

function ScoreDisclaimer() {
  return (
    <div style={{ fontSize: 10.5, color: COLORS.muted, textAlign: "center", lineHeight: 1.4, maxWidth: 300, margin: "6px auto 0" }}>
      Measures cut pacing, audio, and technical execution — not a prediction of views, engagement, or how good the video is.
    </div>
  );
}

function RadialRing({ score, color, size = 56, stroke = 5 }) {
  const [animated, setAnimated] = useState(0);
  useEffect(() => {
    const id = requestAnimationFrame(() => setTimeout(() => setAnimated(score), 30));
    return () => cancelAnimationFrame(id);
  }, [score]);
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const offset = circumference * (1 - animated / 100);
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={COLORS.panelBorder} strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
        strokeDasharray={circumference} strokeDashoffset={offset}
        style={{ transition: "stroke-dashoffset 1s cubic-bezier(.34,1.56,.64,1)" }} />
    </svg>
  );
}

function CategoryCard({ cat }) {
  const Icon = ICONS[cat.icon];
  if (cat.unavailable) {
    return (
      <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "14px 16px", flex: 1, minWidth: 130, opacity: 0.6 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 56, height: 56, borderRadius: "50%", border: `2px dashed ${COLORS.panelBorder}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Icon size={13} color={COLORS.muted} />
          </div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, color: COLORS.muted, fontFamily: "ui-monospace, monospace", lineHeight: 1 }}>N/A</div>
            <div style={{ fontSize: 11, color: COLORS.muted, fontFamily: "ui-monospace, monospace", marginTop: 3 }}>{cat.label}</div>
            <div style={{ fontSize: 9.5, color: COLORS.muted, marginTop: 2 }}>No audio track</div>
          </div>
        </div>
      </div>
    );
  }
  const color = cat.score >= 75 ? COLORS.green : cat.score >= 45 ? COLORS.amber : COLORS.red;
  return (
    <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "14px 16px", flex: 1, minWidth: 130, transition: "transform 0.15s, box-shadow 0.15s", cursor: "default" }}
      onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = `0 8px 20px ${color}22`; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "none"; }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ position: "relative", width: 56, height: 56, flexShrink: 0 }}>
          <RadialRing score={cat.score} color={color} />
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
            <Icon size={13} color={color} />
          </div>
        </div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 800, color, lineHeight: 1.15 }}>{scoreTier(cat.score)}</div>
          <div style={{ fontSize: 11, color: COLORS.muted, fontFamily: "ui-monospace, monospace", marginTop: 3 }}>{cat.label}</div>
        </div>
      </div>
    </div>
  );
}

function Waveform({ duration, issues, windows, locked, silenceDb, onSeek }) {
  const maxBars = 90;
  const step = Math.max(1, Math.floor(windows.length / maxBars));
  const bars = [];
  for (let i = 0; i < windows.length; i += step) bars.push(windows[i]);
  return (
    <div style={{ position: "relative", height: 72, background: `linear-gradient(180deg, ${COLORS.panel}, ${COLORS.inputBg})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, overflow: "hidden", padding: "0 4px" }}>
      <div style={{ display: "flex", alignItems: "center", height: "100%", gap: 1.5, filter: locked ? "blur(3px)" : "none" }}>
        {bars.map((w, i) => {
          const norm = clamp((w.db + 60) / 60, 0.04, 1);
          const isSilent = w.db < silenceDb;
          const color = isSilent ? COLORS.panelBorder : `hsl(${190 + norm * 100}, 75%, ${45 + norm * 15}%)`;
          return <div key={i} style={{ flex: 1, height: `${8 + norm * 82}%`, background: color, borderRadius: 1 }} />;
        })}
      </div>
      {!locked && issues.map((issue, i) => (
        <div key={`issue-${i}`} title={onSeek ? `${issue.text} (click to jump here)` : issue.text}
          onClick={() => onSeek && onSeek(issue.t)}
          style={{
            position: "absolute", left: `${(issue.t / duration) * 100}%`, top: 3, width: 9, height: 9, marginLeft: -4.5, borderRadius: "50%",
            background: severityColor(issue.severity), border: `2px solid ${COLORS.inputBg}`, boxShadow: `0 0 6px ${severityColor(issue.severity)}`,
            cursor: onSeek ? "pointer" : "default",
          }} />
      ))}
      {locked && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, color: COLORS.muted, fontSize: 12 }}>
          <Lock size={13} /> Unlock to see exact issue timestamps
        </div>
      )}
    </div>
  );
}

function SafeZoneOverlay({ zone }) {
  if (!zone) return null;
  return (
    <>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: `${zone.top}%`, background: "rgba(244,80,107,0.28)", borderBottom: "1px dashed rgba(244,80,107,0.7)" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: `${zone.bottom}%`, background: "rgba(244,80,107,0.28)", borderTop: "1px dashed rgba(244,80,107,0.7)" }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, right: 0, width: `${zone.right}%`, background: "rgba(244,80,107,0.28)", borderLeft: "1px dashed rgba(244,80,107,0.7)" }} />
    </>
  );
}

function HeatmapOverlay({ heatmap }) {
  if (!heatmap) return null;
  const { cols, rows, cells } = heatmap;
  return (
    <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "35%", display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gridTemplateRows: `repeat(${rows}, 1fr)` }}>
      {cells.map((v, i) => (
        <div key={i} style={{ background: `hsla(${(1 - v) * 220}, 90%, 55%, ${0.1 + v * 0.45})` }} />
      ))}
    </div>
  );
}

function HookAnalysisNote({ report, heatmap, hookWindow }) {
  const firstCut = report.cuts.length > 0 ? report.cuts[0] : null;
  const frame0Db = report.windows.length > 0 ? report.windows[0].db : null;
  const heatmapAvg = heatmap && heatmap.cells.length ? heatmap.cells.reduce((s, v) => s + v, 0) / heatmap.cells.length : null;
  const motionLabel = heatmapAvg == null ? null : heatmapAvg > 0.35 ? "high" : heatmapAvg > 0.15 ? "moderate" : "low";

  const parts = [];
  if (firstCut !== null) {
    parts.push(firstCut <= hookWindow
      ? `The first visual change happens at ${firstCut.toFixed(2)}s, inside the ${hookWindow}s hook window this format expects.`
      : `The first visual change doesn't happen until ${firstCut.toFixed(2)}s — later than the ${hookWindow}s window this format expects.`);
  } else {
    parts.push("No cuts were detected at all, so there's no measured visual change in the opening seconds.");
  }
  if (frame0Db != null && frame0Db > -90) {
    parts.push(`Audio opens around ${frame0Db.toFixed(1)}dB${frame0Db < -40 ? " — starting on near-silence" : ""}.`);
  }
  if (motionLabel) {
    parts.push(`Pixel motion in the first 3 seconds reads as ${motionLabel}, based on frame-to-frame differences in that window.`);
  }

  return (
    <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "14px 16px", marginBottom: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <Zap size={14} color={COLORS.amber} />
        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>Hook read</div>
      </div>
      <div style={{ fontSize: 12.5, color: COLORS.text, lineHeight: 1.6 }}>{parts.join(" ")}</div>
      <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 8, lineHeight: 1.4 }}>
        This is a technical read of the opening frames — cuts, audio level, and pixel motion. It can't judge whether the opening is actually interesting, funny, or clear; that still needs a human (or the Visual Critique below, which at least looks at real frames).
      </div>
    </div>
  );
}

function VideoPreview({ url, videoRef, safeZonePlatform, setSafeZonePlatform, showHeatmap, setShowHeatmap, heatmap, frame0Db }) {
  if (!url) {
    return (
      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: 20, textAlign: "center", marginBottom: 18 }}>
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          Preview unavailable — this report was reopened from History and the source video isn't kept in memory. Run a fresh analysis to preview it.
        </div>
      </div>
    );
  }
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <div style={{ position: "relative", width: "100%", maxWidth: 220, aspectRatio: "9 / 16", borderRadius: 12, overflow: "hidden", background: "#000", border: `1px solid ${COLORS.panelBorder}` }}>
          <video ref={videoRef} src={url} controls playsInline style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }} />
          <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
            {showHeatmap && <HeatmapOverlay heatmap={heatmap} />}
            <SafeZoneOverlay zone={SAFE_ZONES[safeZonePlatform]} />
          </div>
        </div>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 6, marginTop: 10 }}>
        {[["none", "No overlay"], ...Object.entries(SAFE_ZONES).map(([k, z]) => [k, z.label])].map(([key, label]) => (
          <button key={key} onClick={() => setSafeZonePlatform(key)} style={{
            background: safeZonePlatform === key ? `${COLORS.violet}22` : "transparent",
            color: safeZonePlatform === key ? COLORS.violet : COLORS.muted,
            border: `1px solid ${safeZonePlatform === key ? COLORS.violet : COLORS.panelBorder}`,
            borderRadius: 14, padding: "4px 11px", fontSize: 11, cursor: "pointer",
          }}>{label}</button>
        ))}
        <button onClick={() => setShowHeatmap(!showHeatmap)} disabled={!heatmap} style={{
          background: showHeatmap ? `${COLORS.cyan}22` : "transparent", color: !heatmap ? COLORS.panelBorder : showHeatmap ? COLORS.cyan : COLORS.muted,
          border: `1px solid ${showHeatmap ? COLORS.cyan : COLORS.panelBorder}`, borderRadius: 14, padding: "4px 11px", fontSize: 11,
          cursor: heatmap ? "pointer" : "default",
        }}>Hook heatmap (0-3s)</button>
      </div>

      <div style={{ fontSize: 10.5, color: COLORS.muted, textAlign: "center", marginTop: 8, lineHeight: 1.4 }}>
        Safe zones are approximate, from third-party creator guides — not official platform specs. Frame-0 audio level: {frame0Db != null ? `${frame0Db.toFixed(1)} dB` : "n/a"}.
      </div>
    </div>
  );
}

function IssueCard({ issue }) {
  const Icon = ICONS[{ hook: "Zap", pacing: "Scissors", silence: "Clock", audio: "Volume2", platform: "Film" }[issue.type]] || AlertTriangle;
  const color = severityColor(issue.severity);
  return (
    <div style={{ background: `linear-gradient(135deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderLeft: `3px solid ${color}`, borderRadius: 8, padding: "12px 14px", display: "flex", gap: 12, alignItems: "flex-start" }}>
      <div style={{ width: 26, height: 26, borderRadius: 7, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: `${color}22`, color }} aria-hidden="true"><Icon size={14} /></div>
      <div>
        <div style={{ fontSize: 13.5, lineHeight: 1.55, color: COLORS.text, fontWeight: issue.why ? 600 : 400 }}>{issue.problem || issue.text}</div>
        {issue.why && <div style={{ fontSize: 12, lineHeight: 1.5, color: COLORS.muted, marginTop: 4 }}><span style={{ fontWeight: 700, color }}>Why it matters: </span>{issue.why}</div>}
      </div>
    </div>
  );
}

const CHECKS = [
  { icon: Zap, label: "Hook timing", desc: "Movement in the first 1.5s?" },
  { icon: Scissors, label: "Cut pacing", desc: "Shots too slow or too choppy?" },
  { icon: Clock, label: "Dead air", desc: "Silent gaps that kill momentum?" },
  { icon: Volume2, label: "Audio jumps", desc: "Uneven volume between splices?" },
  { icon: Film, label: "Platform fit", desc: "Right aspect ratio for Shorts/Reels?" },
  { icon: Copy, label: "Duplicate check", desc: "Has this exact file been checked before?" },
];

const HOW_IT_WORKS = [
  { icon: Upload, label: "1. Upload", desc: "Drop in an edited video — nothing leaves your browser." },
  { icon: Zap, label: "2. Analyze", desc: "Real checks run on pacing, audio, hook timing, and platform fit." },
  { icon: Lightbulb, label: "3. Get fixes", desc: "See exactly what's flagged, why it matters, and what to change." },
];

// Real steps the analysis pipeline actually runs, in order — used to show
// a genuine progress checklist rather than a generic spinner. Each label
// here corresponds to a real setPhase() call in runAnalysis.
const ANALYSIS_STAGES = [
  "Reading video file",
  "Analyzing audio track",
  "Analyzing cuts, pacing & thumbnail",
  "Reading hook-zone motion",
  "Generating report",
];

function Stars({ value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 3 }} role={onChange ? "radiogroup" : undefined} aria-label={onChange ? "Rating" : `Rated ${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <Star key={n} size={16} onClick={() => onChange && onChange(n)}
          role={onChange ? "radio" : undefined} aria-checked={onChange ? n === value : undefined}
          aria-label={onChange ? `${n} star${n === 1 ? "" : "s"}` : undefined}
          tabIndex={onChange ? 0 : -1}
          onKeyDown={onChange ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onChange(n); } } : undefined}
          style={{ cursor: onChange ? "pointer" : "default", color: n <= value ? COLORS.amber : COLORS.panelBorder }}
          fill={n <= value ? COLORS.amber : "none"} />
      ))}
    </div>
  );
}

function DataCard({ title, icon: Icon, children }) {
  return (
    <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "16px 18px", marginBottom: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        {Icon && <Icon size={14} color={COLORS.cyan} />}
        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>{title}</div>
      </div>
      {children}
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${COLORS.panelBorder}` }}>
      <span style={{ fontSize: 12.5, color: COLORS.muted }}>{label}</span>
      <span style={{ fontSize: 12.5, fontFamily: "ui-monospace, monospace", fontWeight: 600 }}>{value}</span>
    </div>
  );
}

function VideoInfoCard({ info, fileName }) {
  return (
    <DataCard title="Video information" icon={Film}>
      <InfoRow label="File" value={fileName} />
      <InfoRow label="Duration" value={`${info.duration.toFixed(2)}s`} />
      <InfoRow label="Resolution" value={`${info.width}×${info.height}`} />
      <InfoRow label="Aspect ratio" value={`${info.ratio}:1 — ${info.aspectLabel}`} />
    </DataCard>
  );
}

function NLEExportCard({ report, fileName, fps, setFps, onEDL, onFCPXML }) {
  const keepCount = computeKeepSegments(report.duration, report.silenceGaps).length;
  const removedCount = report.silenceGaps.length;
  return (
    <DataCard title="Export to editor" icon={Scissors}>
      <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5, marginBottom: 12 }}>
        Builds a timeline with {removedCount} silent gap{removedCount === 1 ? "" : "s"} already cut out ({keepCount} clip{keepCount === 1 ? "" : "s"} remain), plus markers for every scene cut and audio peak. You'll need to relink the source file in your editor after import — this doesn't embed the actual video.
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
        <span style={{ fontSize: 11.5, color: COLORS.muted }}>Source frame rate:</span>
        {[24, 25, 30, 60].map((f) => (
          <button key={f} onClick={() => setFps(f)} style={{
            background: fps === f ? `${COLORS.violet}22` : "transparent", color: fps === f ? COLORS.violet : COLORS.text,
            border: `1px solid ${fps === f ? COLORS.violet : COLORS.panelBorder}`, borderRadius: 14, padding: "4px 11px",
            fontSize: 11.5, cursor: "pointer",
          }}>{f}fps</button>
        ))}
      </div>
      <div style={{ fontSize: 10.5, color: COLORS.muted, marginBottom: 12, lineHeight: 1.4 }}>
        The browser can't read your source file's actual frame rate — pick the one that matches your footage, or timecodes will drift once imported.
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button onClick={() => onEDL(report, fileName, fps)} style={{
          background: `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`, color: "#0F0B1E", border: "none",
          borderRadius: 7, padding: "8px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer",
        }}>Export EDL (Premiere)</button>
        <button onClick={() => onFCPXML(report, fileName, fps)} style={{
          background: "transparent", color: COLORS.text, border: `1px solid ${COLORS.panelBorder}`,
          borderRadius: 7, padding: "8px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer",
        }}>Export FCPXML (Resolve/FCP)</button>
      </div>
    </DataCard>
  );
}

function ShotTable({ shots }) {
  return (
    <DataCard title="Editing breakdown — shot by shot" icon={Scissors}>
      <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 280, overflowY: "auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "28px 1fr 60px 70px 70px", gap: 8, fontSize: 10.5, color: COLORS.muted, padding: "4px 6px", fontFamily: "ui-monospace, monospace", textTransform: "uppercase" }}>
          <span>#</span><span>Timestamp</span><span>Length</span><span>Light</span><span>Tone</span>
        </div>
        {shots.map((s) => (
          <div key={s.index} style={{ display: "grid", gridTemplateColumns: "28px 1fr 60px 70px 70px", gap: 8, fontSize: 12, padding: "6px 6px", background: s.index % 2 === 0 ? COLORS.panelAlt : "transparent", borderRadius: 4, alignItems: "center" }}>
            <span style={{ color: COLORS.muted }}>{s.index}</span>
            <span style={{ fontFamily: "ui-monospace, monospace" }}>{fmtTime(s.start)} – {fmtTime(s.end)}</span>
            <span style={{ fontFamily: "ui-monospace, monospace" }}>{s.length.toFixed(2)}s</span>
            <span style={{ color: s.lightLabel === "Dark" ? COLORS.muted : s.lightLabel === "Bright" ? COLORS.amber : COLORS.text }}>{s.lightLabel}</span>
            <span style={{ color: s.colorLabel === "Warm" ? COLORS.amber : s.colorLabel === "Cool" ? COLORS.cyan : COLORS.muted }}>{s.colorLabel}</span>
          </div>
        ))}
      </div>
    </DataCard>
  );
}

function AudioInfoCard({ audioInfo }) {
  if (audioInfo.hasAudio === false) {
    return (
      <DataCard title="Audio analysis" icon={Volume2}>
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5, display: "flex", alignItems: "flex-start", gap: 8 }}>
          <AlertTriangle size={14} color={COLORS.amber} style={{ flexShrink: 0, marginTop: 1 }} />
          No audio track was detected in this file — silence/audio-jump checks and the two audio-related category
          scores are skipped rather than shown as misleadingly perfect.
        </div>
      </DataCard>
    );
  }
  return (
    <DataCard title="Audio analysis" icon={Volume2}>
      <InfoRow label="Average level" value={`${audioInfo.avgDb.toFixed(1)} dB`} />
      <InfoRow label="Dynamic range" value={`${audioInfo.dynamicRange.toFixed(1)} dB`} />
      <InfoRow label="Total silence" value={`${audioInfo.silenceTotal.toFixed(2)}s`} />
      <div style={{ marginTop: 10 }}>
        <div style={{ fontSize: 11.5, color: COLORS.muted, marginBottom: 6 }}>Energy peaks (loudest moments)</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {audioInfo.peaks.length === 0 ? <span style={{ fontSize: 11.5, color: COLORS.muted }}>None detected</span> :
            audioInfo.peaks.map((p, i) => (
              <span key={i} style={{ fontSize: 11, fontFamily: "ui-monospace, monospace", background: COLORS.panelBorder, padding: "3px 8px", borderRadius: 12, color: COLORS.cyan }}>{fmtTime(p.t)}</span>
            ))}
        </div>
      </div>
    </DataCard>
  );
}

function ColorInfoCard({ colorInfo }) {
  return (
    <DataCard title="Color &amp; lighting" icon={ImageIcon}>
      <InfoRow label="Average brightness" value={`${colorInfo.avgBrightness.toFixed(0)} / 255`} />
      <InfoRow label="Overall tone" value={colorInfo.overallTone} />
      <InfoRow label="Warm shots" value={`${colorInfo.warmShots} / ${colorInfo.totalShots}`} />
      <InfoRow label="Cool shots" value={`${colorInfo.coolShots} / ${colorInfo.totalShots}`} />
    </DataCard>
  );
}

function AIFeatureDisabledNotice({ title, icon: Icon }) {
  return (
    <div style={{
      background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px dashed ${COLORS.panelBorder}`,
      borderRadius: 10, padding: "16px 18px", marginBottom: 14,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <Icon size={14} color={COLORS.muted} />
        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>{title}</div>
      </div>
      <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
        Turned off in this build to keep CutScope genuinely free — this feature needs a paid AI backend, which isn't connected here. Everything else on this page is fully real and doesn't need it.
      </div>
    </div>
  );
}

function AIEditorCard({ status, notes, onGenerate, tone, setTone }) {
  const lines = (notes || "").split("\n").filter((l) => l.trim());
  return (
    <div style={{
      background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.violet}55`,
      borderRadius: 10, padding: "16px 18px", marginBottom: 14,
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Sparkles size={14} color={COLORS.violet} />
          <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>AI editor notes</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ display: "flex", border: `1px solid ${COLORS.panelBorder}`, borderRadius: 7, overflow: "hidden" }}>
            {[["coach", "Coach"], ["critic", "Critic"]].map(([key, label]) => (
              <button key={key} onClick={() => setTone(key)} style={{
                background: tone === key ? `${COLORS.violet}33` : "transparent", color: tone === key ? COLORS.violet : COLORS.muted,
                border: "none", padding: "5px 10px", fontSize: 11, fontWeight: 600, cursor: "pointer",
              }}>{label}</button>
            ))}
          </div>
          {status !== "loading" && (
            <button onClick={onGenerate} style={{
              display: "flex", alignItems: "center", gap: 5, background: status === "done" ? "transparent" : `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`,
              color: status === "done" ? COLORS.muted : "#0F0B1E", border: status === "done" ? `1px solid ${COLORS.panelBorder}` : "none",
              borderRadius: 7, padding: "6px 12px", fontSize: 11.5, fontWeight: 700, cursor: "pointer",
            }}>
              {status === "done" ? <><RefreshCw size={11} /> Regenerate</> : <><Sparkles size={11} /> Generate notes</>}
            </button>
          )}
        </div>
      </div>

      {status === "idle" && (
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          Sends your video's measured data (scores, timestamps, silence, audio levels) to Google Gemini and gets back a
          plain-English editing checklist. Nothing about the video's actual content is guessed — only what was measured.
        </div>
      )}
      {status === "loading" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[100, 85, 92, 70].map((w, i) => (
            <div key={i} style={{ height: 12, width: `${w}%`, borderRadius: 4, background: COLORS.panelBorder, opacity: 0.6, animation: "pulse 1.4s ease-in-out infinite" }} />
          ))}
          <style>{`@keyframes pulse { 0%,100% { opacity: 0.35; } 50% { opacity: 0.8; } }`}</style>
        </div>
      )}
      {status === "error" && (
        <div style={{ fontSize: 12.5, color: COLORS.red }}>Couldn't reach the AI service — try again in a moment.</div>
      )}
      {status === "done" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {lines.map((line, i) => (
            <div key={i} style={{ fontSize: 13, lineHeight: 1.55, color: COLORS.text, whiteSpace: "pre-wrap" }}>{line}</div>
          ))}
        </div>
      )}
    </div>
  );
}

const CHAT_SUGGESTIONS = ["What's the biggest problem?", "Explain the audio score", "What should I fix first?"];

function ChatCard({ messages, input, setInput, loading, error, onSend }) {
  const scrollRef = useRef(null);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.trim() && !loading) onSend(input);
  };

  return (
    <div style={{
      background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`,
      borderRadius: 10, padding: "16px 18px", marginBottom: 14,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <Sparkles size={14} color={COLORS.violet} />
        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>Ask about this video</div>
      </div>

      {messages.length === 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5, marginBottom: 10 }}>
            Chat with an assistant grounded in this video's measured data — cuts, timestamps, audio levels. It won't guess at things it can't see.
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {CHAT_SUGGESTIONS.map((s, i) => (
              <button key={i} onClick={() => onSend(s)} style={{
                background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 14, padding: "5px 11px",
                fontSize: 11.5, color: COLORS.text, cursor: "pointer",
              }}>{s}</button>
            ))}
          </div>
        </div>
      )}

      {messages.length > 0 && (
        <div ref={scrollRef} style={{ maxHeight: 280, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8, marginBottom: 12 }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "85%",
              background: m.role === "user" ? `${COLORS.violet}22` : COLORS.inputBg,
              border: `1px solid ${m.role === "user" ? COLORS.violet + "44" : COLORS.panelBorder}`,
              borderRadius: 10, padding: "8px 12px", fontSize: 13, lineHeight: 1.5, color: COLORS.text, whiteSpace: "pre-wrap",
            }}>{m.text}</div>
          ))}
          {loading && (
            <div style={{ alignSelf: "flex-start", display: "flex", gap: 4, padding: "8px 12px" }}>
              {[0, 1, 2].map((i) => (
                <div key={i} style={{
                  width: 6, height: 6, borderRadius: "50%", background: COLORS.muted,
                  animation: `bounce 1s ${i * 0.15}s infinite ease-in-out`,
                }} />
              ))}
              <style>{`@keyframes bounce { 0%,100% { opacity: 0.3; } 50% { opacity: 1; } }`}</style>
            </div>
          )}
        </div>
      )}

      {error && <div style={{ fontSize: 11.5, color: COLORS.red, marginBottom: 8 }}>{error}</div>}

      <form onSubmit={handleSubmit} style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask a question…" disabled={loading}
          style={{ flex: 1, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, padding: "9px 12px", color: COLORS.text, fontSize: 13, outline: "none" }} />
        <button type="submit" disabled={loading || !input.trim()} style={{
          background: loading || !input.trim() ? COLORS.panelBorder : `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`,
          color: loading || !input.trim() ? COLORS.muted : "#0F0B1E", border: "none", borderRadius: 8, padding: "9px 16px",
          fontSize: 13, fontWeight: 700, cursor: loading || !input.trim() ? "default" : "pointer",
        }}>Send</button>
      </form>
    </div>
  );
}

function VisionCritiqueCard({ status, notes, onGenerate, frames }) {
  const lines = (notes || "").split("\n").filter((l) => l.trim());
  const hasFrames = frames && frames.length > 0;
  return (
    <div style={{
      background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.cyan}55`,
      borderRadius: 10, padding: "16px 18px", marginBottom: 14,
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <ImageIcon size={14} color={COLORS.cyan} />
          <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>Visual content critique</div>
        </div>
        {status !== "loading" && hasFrames && (
          <button onClick={onGenerate} style={{
            display: "flex", alignItems: "center", gap: 5, background: status === "done" ? "transparent" : `linear-gradient(90deg, ${COLORS.cyan}, ${COLORS.violet})`,
            color: status === "done" ? COLORS.muted : "#0F0B1E", border: status === "done" ? `1px solid ${COLORS.panelBorder}` : "none",
            borderRadius: 7, padding: "6px 12px", fontSize: 11.5, fontWeight: 700, cursor: "pointer",
          }}>
            {status === "done" ? <><RefreshCw size={11} /> Regenerate</> : <><Sparkles size={11} /> Analyze frames</>}
          </button>
        )}
      </div>

      {!hasFrames && (
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          Not available — this report was reopened from History, and sample frames aren't saved (keeps saved reports small). Run a fresh analysis to use this.
        </div>
      )}
      {hasFrames && (
        <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
          {frames.map((f, i) => (
            <img key={i} src={f.dataUrl} alt={`Sample frame ${i + 1} from the video`} style={{ width: 56, height: 56, objectFit: "cover", borderRadius: 6, border: `1px solid ${COLORS.panelBorder}` }} />
          ))}
        </div>
      )}
      {hasFrames && status === "idle" && (
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          Sends these {frames.length} frames to Google Gemini and gets back an honest read on framing, composition, and on-screen
          text — based only on what's visible in these stills. No motion, audio, or story context, and no invented "virality" score.
        </div>
      )}
      {status === "loading" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[95, 80, 88].map((w, i) => (
            <div key={i} style={{ height: 12, width: `${w}%`, borderRadius: 4, background: COLORS.panelBorder, opacity: 0.6, animation: "pulse 1.4s ease-in-out infinite" }} />
          ))}
        </div>
      )}
      {status === "error" && (
        <div style={{ fontSize: 12.5, color: COLORS.red }}>Couldn't reach the AI service — try again in a moment.</div>
      )}
      {status === "done" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {lines.map((line, i) => (
            <div key={i} style={{ fontSize: 13, lineHeight: 1.55, color: COLORS.text, whiteSpace: "pre-wrap" }}>{line}</div>
          ))}
        </div>
      )}
    </div>
  );
}

function SuggestionsCard({ suggestions }) {
  return (
    <DataCard title="Priority fixes for this video" icon={Lightbulb}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {suggestions.map((s, i) => {
          const Icon = ICONS[s.icon] || Lightbulb;
          const color = severityColor(s.priority === "high" ? "high" : s.priority === "medium" ? "medium" : "low");
          return (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "8px 0", borderBottom: i < suggestions.length - 1 ? `1px solid ${COLORS.panelBorder}` : "none" }}>
              <div style={{ width: 24, height: 24, borderRadius: 6, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: `${color}22`, color }}>
                <Icon size={13} />
              </div>
              <div style={{ flex: 1 }}>
                <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", color, fontFamily: "ui-monospace, monospace", marginRight: 8 }}>
                  {s.priority}
                </span>
                <span style={{ fontSize: 13, lineHeight: 1.5 }}>{s.action}</span>
              </div>
            </div>
          );
        })}
      </div>
    </DataCard>
  );
}

const PLAYBOOK = [
  { icon: HelpCircle, title: "Open a loop", desc: "Tease something ('wait for it', an unanswered question) early so viewers stay to find out how it resolves." },
  { icon: Repeat, title: "Pattern interrupt every 2-3s", desc: "A zoom, sound hit, or angle change resets attention before the brain gets bored and scrolls." },
  { icon: Zap, title: "Deliver the payoff fast", desc: "Don't build up for 10s to a 1s punchline — viral clips front-load the reason to keep watching." },
  { icon: Volume2, title: "Sound sells the cut", desc: "A whoosh, click, or beat-drop on a hard cut makes edits feel intentional, not accidental." },
];

function PlaybookCard() {
  return (
    <DataCard title="General retention playbook" icon={Lightbulb}>
      <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 12, lineHeight: 1.5 }}>
        Evergreen editing principles — not measured from your video, general best practices worth keeping in mind.
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {PLAYBOOK.map((p, i) => (
          <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
            <div style={{ width: 24, height: 24, borderRadius: 6, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: `${COLORS.violet}22`, color: COLORS.violet }}>
              <p.icon size={13} />
            </div>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700 }}>{p.title}</div>
              <div style={{ fontSize: 11.5, color: COLORS.muted, lineHeight: 1.45, marginTop: 1 }}>{p.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </DataCard>
  );
}

const SEED_REVIEWS = [
  { name: "Example", country: "", rating: 5, text: "This is a placeholder — real reviews from actual users will show up here once people start using the tool.", ts: 0, isExample: true },
];

const NAV_ITEMS = [
  { key: "analyze", label: "Dashboard", icon: LayoutDashboard },
  { key: "history", label: "History", icon: HistoryIcon },
  { key: "pricing", label: "Pricing", icon: Tag },
  { key: "reviews", label: "Reviews", icon: Star },
  { key: "settings", label: "Settings", icon: SettingsIcon },
];

function Sidebar({ open, setOpen, activePage, setActivePage, isMobile }) {
  // On mobile, an expanded sidebar overlays the content (fixed position + backdrop)
  // instead of squeezing it into a narrow column — that squeeze was the real cause
  // of the broken, one-word-per-line mobile layout.
  const overlay = isMobile && open;
  return (
    <>
      {overlay && (
        <div onClick={() => setOpen(false)} style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 40,
        }} />
      )}
      <div style={{
        width: open ? 208 : 64, flexShrink: 0, background: COLORS.sidebarBg, borderRight: `1px solid ${COLORS.panelBorder}`,
        display: "flex", flexDirection: "column", transition: "width 0.2s ease", height: "100vh",
        position: overlay ? "fixed" : "sticky", top: 0, left: 0, zIndex: overlay ? 41 : undefined,
        boxShadow: overlay ? "2px 0 24px rgba(0,0,0,0.4)" : "none",
      }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "18px 16px", borderBottom: `1px solid ${COLORS.panelBorder}` }}>
        <div style={{ width: 26, height: 26, borderRadius: 7, background: `linear-gradient(135deg, ${COLORS.violet}, ${COLORS.cyan})`, flexShrink: 0 }} />
        {open && <div style={{ fontWeight: 800, fontSize: 15, whiteSpace: "nowrap", color: COLORS.text }}>CutScope</div>}
      </div>
      <div style={{ flex: 1, padding: "12px 8px", display: "flex", flexDirection: "column", gap: 3 }}>
        {NAV_ITEMS.map((item) => {
          const active = activePage === item.key;
          return (
            <button key={item.key} onClick={() => { setActivePage(item.key); if (isMobile) setOpen(false); }} title={item.label}
              style={{
                display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 8, border: "none",
                background: active ? `${COLORS.violet}22` : "transparent", color: active ? COLORS.violet : COLORS.muted,
                cursor: "pointer", fontSize: 13, fontWeight: active ? 700 : 500, transition: "background 0.15s",
                justifyContent: open ? "flex-start" : "center",
              }}
              onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = `${COLORS.panelBorder}66`; }}
              onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = "transparent"; }}>
              <item.icon size={16} />
              {open && <span style={{ whiteSpace: "nowrap" }}>{item.label}</span>}
            </button>
          );
        })}
      </div>
      {open && (
        <div style={{ display: "flex", gap: 8, padding: "0 16px 10px", fontSize: 10.5 }}>
          <button onClick={() => { setActivePage("terms"); if (isMobile) setOpen(false); }} style={{ background: "none", border: "none", color: activePage === "terms" ? COLORS.violet : COLORS.muted, cursor: "pointer", padding: 0, textDecoration: "underline" }}>Terms</button>
          <button onClick={() => { setActivePage("privacy"); if (isMobile) setOpen(false); }} style={{ background: "none", border: "none", color: activePage === "privacy" ? COLORS.violet : COLORS.muted, cursor: "pointer", padding: 0, textDecoration: "underline" }}>Privacy</button>
          <button onClick={() => { setActivePage("refund"); if (isMobile) setOpen(false); }} style={{ background: "none", border: "none", color: activePage === "refund" ? COLORS.violet : COLORS.muted, cursor: "pointer", padding: 0, textDecoration: "underline" }}>Refunds</button>
        </div>
      )}
      <button onClick={() => setOpen(!open)} aria-label={open ? "Collapse sidebar" : "Expand sidebar"} style={{
        margin: 8, padding: "8px", borderRadius: 8, border: `1px solid ${COLORS.panelBorder}`, background: "transparent",
        color: COLORS.muted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 11,
      }}>
        {open ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
        {open && "Collapse"}
      </button>
    </div>
    </>
  );
}

function Topbar({ themeMode, toggleTheme, setActivePage }) {
  return (
    <div style={{
      height: 56, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px", gap: 10,
      background: COLORS.topbarBg, borderBottom: `1px solid ${COLORS.panelBorder}`, position: "sticky", top: 0, zIndex: 5,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, padding: "6px 12px", flex: "1 1 120px", minWidth: 0, maxWidth: 220 }}>
        <Search size={13} color={COLORS.muted} style={{ flexShrink: 0 }} />
        <input placeholder="Search…" style={{ background: "transparent", border: "none", outline: "none", color: COLORS.text, fontSize: 12.5, width: "100%", minWidth: 0 }} />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
        <button onClick={toggleTheme} title="Toggle theme" aria-label="Toggle dark or light theme" style={{
          width: 32, height: 32, borderRadius: 8, border: `1px solid ${COLORS.panelBorder}`, background: "transparent",
          color: COLORS.muted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          {themeMode === "dark" ? <Sun size={15} /> : <Moon size={15} />}
        </button>
        <button onClick={() => setActivePage("settings")} title="Notifications (see Settings)" aria-label="Notification settings" style={{
          width: 32, height: 32, borderRadius: 8, border: `1px solid ${COLORS.panelBorder}`, background: "transparent",
          color: COLORS.muted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", position: "relative",
        }}>
          <Bell size={15} />
        </button>
        <button onClick={() => setActivePage("settings")} title="Settings" aria-label="Open settings" style={{
          width: 32, height: 32, borderRadius: 8, border: `1px solid ${COLORS.panelBorder}`, background: "transparent",
          color: COLORS.muted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <SettingsIcon size={15} />
        </button>
        <div style={{
          width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${COLORS.violet}, ${COLORS.cyan})`,
          display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 12, fontWeight: 700, marginLeft: 4,
        }}>A</div>
      </div>
    </div>
  );
}

function ComingSoon({ label }) {
  return (
    <div style={{ padding: "60px 20px", textAlign: "center", color: COLORS.muted }}>
      <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.text, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 13 }}>Coming soon — this page isn't wired up yet.</div>
    </div>
  );
}

function QuickStats({ historyIndex }) {
  if (historyIndex.length === 0) return null;
  const scores = historyIndex.map((h) => h.score);
  const avgScore = Math.round(scores.reduce((s, v) => s + v, 0) / scores.length);
  const best = historyIndex.reduce((a, b) => (b.score > a.score ? b : a), historyIndex[0]);
  const stats = [
    { label: "Videos analyzed", value: historyIndex.length },
    { label: "Average score", value: avgScore },
    { label: "Best video", value: `${best.score}`, sub: best.fileName },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 10, marginBottom: 18 }} role="group" aria-label="Quick statistics">
      {stats.map((s, i) => (
        <div key={i} style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "12px 14px" }}>
          <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.text, fontFamily: "ui-monospace, monospace" }}>{s.value}</div>
          <div style={{ fontSize: 10.5, color: COLORS.muted, marginTop: 2 }}>{s.label}</div>
          {s.sub && <div style={{ fontSize: 9.5, color: COLORS.muted, marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.sub}</div>}
        </div>
      ))}
    </div>
  );
}

function TrendChart({ historyIndex }) {
  if (historyIndex.length < 2) return null;
  const data = [...historyIndex].sort((a, b) => a.ts - b.ts).map((h) => ({
    date: new Date(h.ts).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
    score: h.score,
  }));
  return (
    <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "16px 12px 8px", marginBottom: 18 }}>
      <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace", marginBottom: 8, paddingLeft: 8 }}>
        Score trend
      </div>
      <ResponsiveContainer width="100%" height={140}>
        <LineChart data={data} margin={{ top: 5, right: 12, left: -18, bottom: 0 }}>
          <CartesianGrid stroke={COLORS.panelBorder} strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="date" tick={{ fontSize: 10, fill: COLORS.muted }} axisLine={{ stroke: COLORS.panelBorder }} tickLine={false} />
          <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: COLORS.muted }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={{ background: COLORS.panelAlt, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, fontSize: 12 }} labelStyle={{ color: COLORS.text }} />
          <Line type="monotone" dataKey="score" stroke={COLORS.violet} strokeWidth={2} dot={{ r: 3, fill: COLORS.violet }} activeDot={{ r: 5 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function TagInput({ value, onCommit }) {
  const [local, setLocal] = useState(value || "");
  useEffect(() => setLocal(value || ""), [value]);
  const commit = () => { if (local !== (value || "")) onCommit(local.trim()); };
  return (
    <input value={local} onChange={(e) => setLocal(e.target.value)} onBlur={commit}
      onKeyDown={(e) => { if (e.key === "Enter") e.currentTarget.blur(); }}
      placeholder="+ tag" list="cutscope-tag-suggestions"
      style={{
        width: 84, background: local ? `${COLORS.violet}18` : "transparent", border: `1px solid ${local ? COLORS.violet + "55" : COLORS.panelBorder}`,
        borderRadius: 12, padding: "3px 8px", fontSize: 10.5, color: local ? COLORS.violet : COLORS.muted, outline: "none",
      }} />
  );
}

function HistoryPage({ historyIndex, historySearch, setHistorySearch, onDelete, onReopen, loading, compareMode, selectedForCompare, onToggleCompareMode, onToggleSelect, onCompareGo, onSetTag }) {
  const [tagFilter, setTagFilter] = useState("all");
  const knownTags = Array.from(new Set(historyIndex.map((h) => h.tag).filter(Boolean))).sort();
  const filtered = historyIndex
    .filter((h) => h.fileName.toLowerCase().includes(historySearch.toLowerCase()))
    .filter((h) => {
      if (tagFilter === "all") return true;
      if (tagFilter === "untagged") return !h.tag;
      return h.tag === tagFilter;
    });
  return (
    <div style={{ maxWidth: 680, margin: "0 auto" }}>
      <datalist id="cutscope-tag-suggestions">
        {knownTags.map((t) => <option key={t} value={t} />)}
      </datalist>
      <div style={{ marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, color: COLORS.text }}>History</h1>
          <p style={{ color: COLORS.muted, fontSize: 13.5, marginTop: 6 }}>
            {historyIndex.length} analysis{historyIndex.length === 1 ? "" : "es"} saved on this device.
          </p>
        </div>
        {compareMode && (
          <button onClick={onCompareGo} disabled={selectedForCompare.length !== 2} style={{
            background: selectedForCompare.length === 2 ? `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})` : COLORS.panelBorder,
            color: selectedForCompare.length === 2 ? "#0F0B1E" : COLORS.muted, border: "none", borderRadius: 7,
            padding: "7px 14px", fontSize: 12, fontWeight: 700, cursor: selectedForCompare.length === 2 ? "pointer" : "default",
          }}>Compare ({selectedForCompare.length}/2)</button>
        )}
      </div>

      <QuickStats historyIndex={historyIndex} />
      <TrendChart historyIndex={historyIndex} />

      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, padding: "8px 12px" }}>
          <Search size={14} color={COLORS.muted} />
          <input value={historySearch} onChange={(e) => setHistorySearch(e.target.value)} placeholder="Search by filename…"
            style={{ background: "transparent", border: "none", outline: "none", color: COLORS.text, fontSize: 13, width: "100%" }} />
        </div>
        <button onClick={onToggleCompareMode} style={{
          background: compareMode ? `${COLORS.violet}22` : "transparent", color: compareMode ? COLORS.violet : COLORS.muted,
          border: `1px solid ${compareMode ? COLORS.violet : COLORS.panelBorder}`, borderRadius: 8, padding: "8px 12px",
          fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap",
        }}>{compareMode ? "Cancel compare" : "Compare"}</button>
      </div>

      {knownTags.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
          {["all", ...knownTags, "untagged"].map((t) => (
            <button key={t} onClick={() => setTagFilter(t)} style={{
              background: tagFilter === t ? `${COLORS.violet}22` : "transparent", color: tagFilter === t ? COLORS.violet : COLORS.muted,
              border: `1px solid ${tagFilter === t ? COLORS.violet : COLORS.panelBorder}`, borderRadius: 14, padding: "4px 11px",
              fontSize: 11, cursor: "pointer", textTransform: "capitalize",
            }}>{t === "all" ? "All" : t === "untagged" ? "Untagged" : t}</button>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "40px 0", color: COLORS.muted, fontSize: 13.5 }}>
          {historyIndex.length === 0 ? "No videos analyzed yet — run a check from the Dashboard." : "No results match that search."}
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map((h) => {
            const color = h.score >= 75 ? COLORS.green : h.score >= 45 ? COLORS.amber : COLORS.red;
            const isSelected = selectedForCompare.includes(h.id);
            return (
              <div key={h.id} style={{
                display: "flex", alignItems: "center", gap: 12, background: COLORS.panel,
                border: `1px solid ${isSelected ? COLORS.violet : COLORS.panelBorder}`,
                borderRadius: 10, padding: 10, transition: "background 0.15s", flexWrap: "wrap",
              }}>
                {compareMode && (
                  <input type="checkbox" checked={isSelected}
                    onChange={() => onToggleSelect(h.id)}
                    disabled={!isSelected && selectedForCompare.length >= 2}
                    style={{ width: 16, height: 16, accentColor: COLORS.violet, flexShrink: 0 }} />
                )}
                {h.thumb ? (
                  <img src={h.thumb} alt={`Thumbnail for ${h.fileName}`} style={{ width: 52, height: 52, objectFit: "cover", borderRadius: 6, flexShrink: 0 }} />
                ) : (
                  <div style={{ width: 52, height: 52, borderRadius: 6, background: COLORS.panelAlt, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Film size={16} color={COLORS.muted} />
                  </div>
                )}
                <div style={{ flex: 1, minWidth: 120 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{h.fileName}</div>
                  <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>
                    {h.duration.toFixed(1)}s · {new Date(h.ts).toLocaleDateString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
                <TagInput value={h.tag} onCommit={(v) => onSetTag(h.id, v)} />
                <div style={{ fontSize: 16, fontWeight: 800, color, fontFamily: "ui-monospace, monospace", width: 34, textAlign: "center" }}>{h.score}</div>
                <button onClick={() => onReopen(h.id)} disabled={loading} title="Reopen" style={{
                  background: `${COLORS.violet}22`, color: COLORS.violet, border: "none", borderRadius: 7, padding: "7px 10px",
                  fontSize: 11.5, cursor: loading ? "default" : "pointer", fontWeight: 700,
                }}>Open</button>
                <button onClick={() => onDelete(h.id)} title="Delete" aria-label="Delete this history entry" style={{
                  background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 7,
                  width: 30, height: 30, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                }}>✕</button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SliderRow({ label, hint, value, min, max, step, onChange, unit }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.text }}>{label}</span>
        <span style={{ fontSize: 12.5, fontFamily: "ui-monospace, monospace", color: COLORS.violet }}>{value}{unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))}
        style={{ width: "100%", accentColor: COLORS.violet }} />
      <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 3, lineHeight: 1.4 }}>{hint}</div>
    </div>
  );
}

function ToggleSwitch({ checked, onChange, disabled }) {
  return (
    <button onClick={disabled ? undefined : onChange} disabled={disabled} style={{
      width: 40, height: 22, borderRadius: 11, border: "none", position: "relative", flexShrink: 0,
      background: checked ? COLORS.violet : COLORS.panelBorder, cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1, transition: "background 0.15s",
    }}>
      <div style={{
        position: "absolute", top: 2, left: checked ? 20 : 2, width: 18, height: 18, borderRadius: "50%",
        background: "#fff", transition: "left 0.15s",
      }} />
    </button>
  );
}

function CompareStat({ label, a, b, higherIsBetter = true, format }) {
  const fmt = format || ((v) => v);
  const aWins = higherIsBetter ? a > b : a < b;
  const bWins = higherIsBetter ? b > a : b < a;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${COLORS.panelBorder}` }}>
      <div style={{ fontSize: 14, fontWeight: 700, color: aWins ? COLORS.green : COLORS.text, textAlign: "right", paddingRight: 12, fontFamily: "ui-monospace, monospace" }}>{fmt(a)}</div>
      <div style={{ fontSize: 11, color: COLORS.muted, textAlign: "center", minWidth: 90 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 700, color: bWins ? COLORS.green : COLORS.text, textAlign: "left", paddingLeft: 12, fontFamily: "ui-monospace, monospace" }}>{fmt(b)}</div>
    </div>
  );
}

const PRICING = {
  price: 9,
  currency: "USD",
  model: "One-time purchase — no subscription, no recurring billing.",
};

// Replace these once the real Gumroad product exists — the license flow
// below won't work until they're real values.
const GUMROAD_PRODUCT_ID = "PhN9m8BzqjkR8eY-phWMDQ==";
const GUMROAD_PRODUCT_URL = "https://awaisnazir.gumroad.com/l/cexfdk";

// Set to true once the Gemini backend proxy + free API key exist (see
// netlify/functions/gemini-proxy.js). Left false keeps this a genuinely
// $0-cost deployment — the three AI features turn off cleanly instead of
// being left clickable and failing.
const AI_FEATURES_ENABLED = true;

// AI features run on Google's Gemini API (free tier — no credit card
// required). Calls always go through /api/gemini, a real backend proxy,
// so the API key never sits in browser-visible code. Unlike some other
// setups, there's no "direct call" fallback here — Gemini has no automatic
// auth available outside a real deployment, so without the proxy configured
// this simply returns a clear "not configured" error rather than quietly
// failing in a confusing way.
//
// HONEST PRIVACY NOTE, kept in sync with the Privacy Policy page: Google's
// free Gemini tier may use submitted data (including video frame images
// sent for Visual Critique) to improve their models, for users outside the
// EU/UK/EEA. This is a real difference from a typical paid API arrangement.
const GEMINI_PROXY_ENDPOINT = "/api/gemini";
const GEMINI_MODEL = "gemini-2.5-flash";

// Converts a simple {system, messages, images, maxTokens} shape into
// Gemini's request format, calls the proxy, and returns plain text —
// so the three feature functions below don't need to know Gemini's
// specific request/response shape.
async function callGeminiAPI({ system, messages, images, maxTokens }) {
  const contents = (messages || []).map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.text }],
  }));

  if (images && images.length && contents.length) {
    // Attach any images to the final (most recent) user turn.
    const last = contents[contents.length - 1];
    last.parts = [
      ...images.map((dataUrl) => ({ inline_data: { mime_type: "image/jpeg", data: dataUrl.split(",")[1] } })),
      ...last.parts,
    ];
  }

  const payload = {
    contents,
    generationConfig: { maxOutputTokens: maxTokens || 800 },
  };
  if (system) payload.systemInstruction = { parts: [{ text: system }] };

  let response;
  try {
    response = await fetch(GEMINI_PROXY_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    throw new Error("Couldn't reach the AI service — check your connection and try again.");
  }

  const data = await response.json();
  if (!response.ok) {
    throw new Error((data && data.error) || "AI service returned an error.");
  }
  const text = (data.candidates || [])
    .flatMap((c) => (c.content && c.content.parts) || [])
    .map((p) => p.text || "")
    .join("");
  if (!text) throw new Error("No response from AI");
  return text;
}

async function verifyGumroadLicense(licenseKey) {
  const body = new URLSearchParams();
  body.append("product_id", GUMROAD_PRODUCT_ID);
  body.append("license_key", licenseKey.trim());
  body.append("increment_uses_count", "false"); // don't burn a use just checking on load
  const response = await fetch("https://api.gumroad.com/v2/licenses/verify", { method: "POST", body });
  const data = await response.json();
  return data; // { success: bool, message?, purchase?: {...} }
}

const FREE_FEATURES = [
  "Overall technical execution score", "All 5 category scores", "Percentile rank vs. other videos analyzed",
  "Duplicate-file check", "Video preview + safe-zone overlays", "Video information card",
];

const PRO_FEATURES = [
  "Full issue-by-issue breakdown with exact timestamps",
  ...(AI_FEATURES_ENABLED ? ["AI Editor Notes (Coach/Critic tone)", "AI chat about your video's data", "Visual content critique (Google Gemini looking at real frames)"] : []),
  "Hook-zone motion heatmap", "Shot-by-shot, audio, and color/lighting tables",
  "EDL/FCPXML export with real silence-stripping", "CSV/JSON data export", "Suggested thumbnail frame",
];

const CONTACT_EMAIL = "awaisnazir139@yahoo.com"; // placeholder — replace before publishing

function LegalHighlight({ children }) {
  return <span style={{ color: COLORS.amber, fontWeight: 700 }}>{children}</span>;
}

function LegalSection({ heading, children }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 13.5, fontWeight: 700, color: COLORS.text, marginBottom: 6 }}>{heading}</div>
      <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.65 }}>{children}</div>
    </div>
  );
}

function LegalPageShell({ title, updated, children }) {
  return (
    <div style={{ maxWidth: 620, margin: "0 auto" }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 24, fontWeight: 900, margin: 0, color: COLORS.text }}>{title}</h1>
        <p style={{ color: COLORS.muted, fontSize: 12, marginTop: 6 }}>Last updated: <LegalHighlight>{updated}</LegalHighlight></p>
      </div>
      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 12, padding: 22 }}>
        {children}
      </div>
    </div>
  );
}

function PrivacyPage() {
  return (
    <LegalPageShell title="Privacy Policy" updated="August 12, 2026">
      <LegalSection heading="The short version">
        Your video file itself is never uploaded anywhere — all core analysis (cuts, silence, audio levels, safe zones, hook heatmap)
        runs entirely in your browser, on your device. A few small pieces of data do leave your browser, listed exactly below.
        If you use the optional AI features (chat, AI Editor Notes, Visual Critique), some data — including actual video frame
        images for Visual Critique — is sent to Google's Gemini API to generate those responses. That's the one place
        "nothing leaves your browser" wouldn't be accurate, so we're saying so directly.
      </LegalSection>
      <LegalSection heading="What stays entirely on your device">
        Your video/audio files, the full technical analysis, your History, your Settings, and your license key once verified.
        None of this is transmitted to us or anyone else during normal analysis.
      </LegalSection>
      <LegalSection heading="What does leave your browser, and why">
        A file fingerprint (not the video itself) for duplicate detection · your numeric score for percentile ranking · a text
        summary of your video's measured data, sent to Google Gemini, only if you use AI Chat or Editor Notes · 4 still frames from
        your video, sent to Google Gemini, only if you use Visual Critique · reviews you choose to submit, shown publicly · your
        license key, sent to Gumroad to verify purchase.
      </LegalSection>
      <LegalSection heading="Important: Google's free-tier AI training policy">
        CutScope's AI features run on Google's <LegalHighlight>free</LegalHighlight> Gemini API tier, which keeps this tool free
        to use. Under Google's terms, data submitted through the free tier may be used to improve their models, for users outside
        the EU/UK/EEA. If you'd rather not have your video frames or analysis data used this way, simply don't use the AI Chat,
        AI Editor Notes, or Visual Critique features — every other part of CutScope works fully without them and never sends
        anything to Google.
      </LegalSection>
      <LegalSection heading="We do not">
        Sell your data, use it for advertising, or share it with anyone beyond what's listed above.
      </LegalSection>
      <LegalSection heading="Third parties">
        Google's Gemini API powers the optional AI features (their privacy policy: policies.google.com/privacy, AI-specific terms:
        ai.google.dev/gemini-api/terms). Gumroad handles payment and license verification (their privacy policy: gumroad.com/privacy).
      </LegalSection>
      <LegalSection heading="Your choices">
        Delete your local History anytime from within the app. Remove a stored license key from Settings. Skip the AI features
        entirely if you'd rather not have any data reach Google. Publicly posted reviews can't be self-edited — contact us if one
        needs to come down.
      </LegalSection>
      <LegalSection heading="Contact">
        Questions about this policy: <LegalHighlight>{CONTACT_EMAIL}</LegalHighlight>
      </LegalSection>
    </LegalPageShell>
  );
}

function RefundPage() {
  return (
    <LegalPageShell title="Refund Policy" updated="August 10, 2026">
      <LegalSection heading="The short version">
        CutScope is a one-time purchase, not a subscription — pay once (<LegalHighlight>${PRICING.price}</LegalHighlight>), get
        lifetime access, nothing to cancel. If it doesn't work for you, we offer a{" "}
        <LegalHighlight>14-day money-back guarantee, no questions asked.</LegalHighlight>
      </LegalSection>
      <LegalSection heading="How it works">
        Email <LegalHighlight>{CONTACT_EMAIL}</LegalHighlight> within 14 days of purchase with your order confirmation or
        license key. We refund the full amount through Gumroad, usually within a few business days — no justification required.
      </LegalSection>
      <LegalSection heading="After a refund">
        Your license key stops verifying, and CutScope returns to free-tier features on your device.
      </LegalSection>
      <LegalSection heading="Technical issues first">
        If something isn't working (analysis failing, license not verifying), reach out before requesting a refund — most
        issues are quick to fix. If we can't resolve it, the guarantee above still applies.
      </LegalSection>
      <LegalSection heading="Contact">
        Questions about a purchase or refund: <LegalHighlight>{CONTACT_EMAIL}</LegalHighlight>
      </LegalSection>
    </LegalPageShell>
  );
}

function TermsPage() {
  return (
    <LegalPageShell title="Terms of Service" updated="September 23, 2026">
      <LegalSection heading="The service">
        CutScope analyzes short-form video (pacing, audio, hook, and motion) to help creators improve their content. Core
        analysis runs entirely in your browser — see the <LegalHighlight>Privacy Policy</LegalHighlight> for exactly what,
        if anything, leaves your device. A free tier is available; CutScope Pro unlocks the full feature set via a
        one-time <LegalHighlight>${PRICING.price}</LegalHighlight> purchase — {PRICING.model}
      </LegalSection>
      <LegalSection heading="Your content">
        You keep full ownership of anything you analyze. You're responsible for having the rights to any video you use
        with CutScope. We don't claim any ownership over your videos, and — as described in the Privacy Policy — your
        video files aren't uploaded anywhere during normal analysis.
      </LegalSection>
      <LegalSection heading="Acceptable use">
        Don't use CutScope to analyze content that's illegal or infringes someone else's rights, and don't try to abuse,
        reverse-engineer, or disrupt the service or the AI features it relies on.
      </LegalSection>
      <LegalSection heading="Payments and refunds">
        CutScope Pro is a one-time purchase processed by Gumroad. See the <LegalHighlight>Refund Policy</LegalHighlight> for
        details — short version: 14-day money-back guarantee, no questions asked.
      </LegalSection>
      <LegalSection heading="No guarantees">
        CutScope's scores and AI-generated suggestions are meant to help guide edits, not to guarantee any outcome (views,
        engagement, virality, etc.). AI-based features may occasionally be inaccurate or unavailable.
      </LegalSection>
      <LegalSection heading="Changes to these terms">
        We may update these terms occasionally. Continuing to use CutScope after a change means you accept the update.
      </LegalSection>
      <LegalSection heading="Contact">
        Questions about these terms: <LegalHighlight>{CONTACT_EMAIL}</LegalHighlight>
      </LegalSection>
    </LegalPageShell>
  );
}

function PricingPage() {
  return (
    <div style={{ maxWidth: 640, margin: "0 auto" }}>
      <div style={{ marginBottom: 24, textAlign: "center" }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, color: COLORS.text }}>Pricing</h1>
        <p style={{ color: COLORS.muted, fontSize: 13.5, marginTop: 6 }}>{PRICING.model}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 20 }}>
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 12, padding: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.muted, marginBottom: 4 }}>Free</div>
          <div style={{ fontSize: 28, fontWeight: 900, color: COLORS.text, marginBottom: 14 }}>$0</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {FREE_FEATURES.map((f, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 12.5, color: COLORS.text }}>
                <CheckCircle2 size={14} color={COLORS.green} style={{ flexShrink: 0, marginTop: 1 }} /> {f}
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1.5px solid ${COLORS.violet}`, borderRadius: 12, padding: 20, position: "relative" }}>
          <div style={{ position: "absolute", top: -10, right: 16, background: `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`, color: "#0F0B1E", fontSize: 10, fontWeight: 800, padding: "3px 10px", borderRadius: 10 }}>NO SUBSCRIPTION</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.violet, marginBottom: 4 }}>Pro</div>
          <div style={{ fontSize: 28, fontWeight: 900, color: COLORS.text, marginBottom: 2 }}>
            ${PRICING.price} <span style={{ fontSize: 13, fontWeight: 500, color: COLORS.muted }}>once</span>
          </div>
          <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 14 }}>Pay once, unlimited use — no expiry.</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {PRO_FEATURES.map((f, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 12.5, color: COLORS.text }}>
                <CheckCircle2 size={14} color={COLORS.violet} style={{ flexShrink: 0, marginTop: 1 }} /> {f}
              </div>
            ))}
          </div>
          <a href={GUMROAD_PRODUCT_URL} target="_blank" rel="noopener noreferrer" style={{
            display: "block", textAlign: "center", marginTop: 18, background: `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`, color: "#0F0B1E",
            border: "none", borderRadius: 8, padding: "11px 22px", fontSize: 13.5, fontWeight: 700, textDecoration: "none",
          }}>Buy Pro for ${PRICING.price} once →</a>
        </div>
      </div>

      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: 16, fontSize: 12, color: COLORS.muted, lineHeight: 1.6 }}>
        No credits, no monthly charge, no "quality drops after you pay." Every score you see is computed the same way whether you've paid or not — Pro just unlocks the detail behind it. Already bought it? Paste the license key you're emailed into the unlock screen shown on any locked report.
      </div>
    </div>
  );
}

function CompareView({ items, onBack }) {
  if (!items || items.length !== 2) return null;
  const [a, b] = items;

  // Chronological order matters for a verify check — earlier upload is "before", later is "after",
  // regardless of the order the two were selected in on the History page.
  const [before, after] = [...items].sort((x, y) => (x.ts || 0) - (y.ts || 0));
  const ISSUE_TYPE_LABELS = { hook: "Hook", pacing: "Pacing", silence: "Dead air", audio: "Audio jump", platform: "Platform fit" };
  const allTypes = Array.from(new Set([...before.report.issues.map((i) => i.type), ...after.report.issues.map((i) => i.type)]));
  const issueCheck = allTypes.map((type) => {
    const wasPresent = before.report.issues.some((i) => i.type === type);
    const stillPresent = after.report.issues.some((i) => i.type === type);
    let status;
    if (wasPresent && !stillPresent) status = "resolved";
    else if (wasPresent && stillPresent) status = "open";
    else status = "new";
    return { type, label: ISSUE_TYPE_LABELS[type] || type, status };
  });
  const STATUS_META = {
    resolved: { label: "Resolved", color: COLORS.green, icon: CheckCircle2 },
    open: { label: "Still present", color: COLORS.amber || "#F5A623", icon: AlertTriangle },
    new: { label: "New since last check", color: COLORS.red, icon: AlertTriangle },
  };

  return (
    <div style={{ maxWidth: 680, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, color: COLORS.text }}>Compare</h1>
        <button onClick={onBack} style={{ background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "6px 12px", fontSize: 12, cursor: "pointer" }}>Back to History</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 18 }}>
        {[a, b].map((item, i) => (
          <div key={i} style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: 12, textAlign: "center" }}>
            {item.thumbnail ? (
              <img src={item.thumbnail} alt={`Thumbnail for ${item.fileName}`} style={{ width: "100%", height: 90, objectFit: "cover", borderRadius: 6, marginBottom: 8 }} />
            ) : (
              <div style={{ width: "100%", height: 90, borderRadius: 6, marginBottom: 8, background: COLORS.panelAlt, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Film size={18} color={COLORS.muted} />
              </div>
            )}
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.fileName}</div>
          </div>
        ))}
      </div>

      {allTypes.length > 0 && (
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: 16, marginBottom: 18 }}>
          <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace", marginBottom: 4 }}>Issue check</div>
          <div style={{ fontSize: 11.5, color: COLORS.muted, marginBottom: 12, lineHeight: 1.4 }}>
            Comparing "{before.fileName}" (earlier) against "{after.fileName}" (later), by issue type.
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {issueCheck.map(({ type, label, status }) => {
              const meta = STATUS_META[status];
              const Icon = meta.icon;
              return (
                <div key={type} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${COLORS.panelBorder}` }}>
                  <span style={{ fontSize: 13, color: COLORS.text }}>{label}</span>
                  <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 700, color: meta.color }}>
                    <Icon size={13} /> {meta.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "8px 16px", marginBottom: 18 }}>
        <CompareStat label="Overall score" a={a.report.score} b={b.report.score} />
        {a.report.categories.map((cat, i) => (
          <CompareStat key={cat.key} label={cat.label} a={cat.score} b={b.report.categories[i]?.score ?? 0} />
        ))}
        <CompareStat label="Duration" a={a.report.duration} b={b.report.duration} higherIsBetter={false} format={(v) => `${v.toFixed(1)}s`} />
        <CompareStat label="Issues found" a={a.report.issues.length} b={b.report.issues.length} higherIsBetter={false} />
        <CompareStat label="Silence (s)" a={a.report.audioInfo.silenceTotal} b={b.report.audioInfo.silenceTotal} higherIsBetter={false} format={(v) => v.toFixed(1)} />
      </div>

      <div style={{ fontSize: 11.5, color: COLORS.muted, textAlign: "center" }}>Green highlights the better value in each row.</div>
    </div>
  );
}

function SettingsPage({ settings, updateSetting, resetSettings, applyPreset, themeMode, toggleTheme, notifEnabled, toggleNotif, isPro, licenseLast4, onRemoveLicense }) {
  const activePreset = matchingPreset(settings);
  return (
    <div style={{ maxWidth: 560, margin: "0 auto" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, color: COLORS.text }}>Settings</h1>
        <p style={{ color: COLORS.muted, fontSize: 13.5, marginTop: 6 }}>Preferences are saved on this device.</p>
      </div>

      <DataCard title="Appearance">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Dark mode</div>
            <div style={{ fontSize: 11.5, color: COLORS.muted, marginTop: 2 }}>Switch between dark and light themes</div>
          </div>
          <ToggleSwitch checked={themeMode === "dark"} onChange={toggleTheme} />
        </div>
      </DataCard>

      <DataCard title="License">
        {isPro ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: COLORS.green, fontWeight: 600 }}>
              <CheckCircle2 size={15} /> Pro unlocked {licenseLast4 && `(key ending ${licenseLast4})`}
            </div>
            <button onClick={onRemoveLicense} style={{ background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "5px 10px", fontSize: 11, cursor: "pointer" }}>Remove license</button>
          </div>
        ) : (
          <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
            Not licensed yet — enter your key on any report's unlock screen after purchasing, or visit the Pricing tab.
            Verification calls Gumroad's public license API directly from your browser; a leaked key can be reused by
            anyone (Gumroad's check isn't device-locked), so treat it like a password.
          </div>
        )}
      </DataCard>

      <DataCard title="Analysis sensitivity — really affects your next scan">
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11.5, color: COLORS.muted, marginBottom: 8, lineHeight: 1.4 }}>
            Platform presets — commonly-recommended starting points, not a scientifically validated per-platform benchmark. Adjust the sliders below afterward if you want.
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {Object.entries(PLATFORM_PRESETS).map(([key, preset]) => (
              <button key={key} onClick={() => applyPreset(preset.values)} style={{
                background: activePreset === key ? `${COLORS.violet}22` : "transparent",
                color: activePreset === key ? COLORS.violet : COLORS.text,
                border: `1px solid ${activePreset === key ? COLORS.violet : COLORS.panelBorder}`,
                borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>{preset.label}</button>
            ))}
          </div>
        </div>
        <SliderRow label="Hook window" hint="How many seconds a video has to show movement before it's flagged as a weak hook."
          value={settings.hookWindow} min={0.5} max={3} step={0.1} unit="s" onChange={(v) => updateSetting("hookWindow", v)} />
        <SliderRow label="Cut sensitivity" hint="Lower = detects smaller/subtler cuts. Higher = only flags big scene changes."
          value={settings.sceneThreshold} min={6} max={30} step={1} unit="" onChange={(v) => updateSetting("sceneThreshold", v)} />
        <SliderRow label="Max ideal shot length" hint="Shots longer than this get flagged as too slow for short-form pacing."
          value={settings.idealMaxShot} min={1} max={6} step={0.5} unit="s" onChange={(v) => updateSetting("idealMaxShot", v)} />
        <SliderRow label="Silence threshold" hint="Audio quieter than this (in dB) counts as dead air."
          value={settings.silenceDb} min={-60} max={-20} step={1} unit=" dB" onChange={(v) => updateSetting("silenceDb", v)} />
        <SliderRow label="Audio jump sensitivity" hint="Minimum dB change between clips to flag as an uneven splice."
          value={settings.rmsJumpDb} min={3} max={16} step={1} unit=" dB" onChange={(v) => updateSetting("rmsJumpDb", v)} />
        <button onClick={resetSettings} style={{
          background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6,
          padding: "6px 12px", fontSize: 12, cursor: "pointer", marginTop: 4,
        }}>Reset to defaults</button>
      </DataCard>

      <DataCard title="Export preferences">
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          CSV and JSON export are available now — look for the buttons on any unlocked report. PDF export still isn't built.
        </div>
      </DataCard>

      <DataCard title="Language">
        <div style={{ fontSize: 12.5, color: COLORS.muted, lineHeight: 1.5 }}>
          English only for now. Additional languages aren't wired up yet.
        </div>
      </DataCard>

      <DataCard title="Notifications">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Analysis complete alerts</div>
            <div style={{ fontSize: 11.5, color: COLORS.muted, marginTop: 2 }}>Preference is saved, but no delivery channel (email/push) is connected yet.</div>
          </div>
          <ToggleSwitch checked={notifEnabled} onChange={toggleNotif} />
        </div>
      </DataCard>
    </div>
  );
}

// Builds the same grounded, measured-data-only summary used by both the AI
// Editor Notes feature and the chat assistant, so answers from either stay
// consistent and never drift into inventing things about the video.
function buildDataSummary(rep) {
  return {
    duration: Number(rep.duration.toFixed(2)),
    overall_score: rep.score,
    category_scores: Object.fromEntries(rep.categories.map((c) => [c.label, c.score])),
    detected_issues: rep.issues.map((i) => ({ type: i.type, severity: i.severity, timestamp: Number(i.t.toFixed(2)), detail: i.text })),
    shots: rep.shots.map((s) => ({ start: Number(s.start.toFixed(2)), end: Number(s.end.toFixed(2)), length: Number(s.length.toFixed(2)), lighting: s.lightLabel, tone: s.colorLabel })),
    audio: { avg_db: Number(rep.audioInfo.avgDb.toFixed(1)), dynamic_range_db: Number(rep.audioInfo.dynamicRange.toFixed(1)), total_silence_s: Number(rep.audioInfo.silenceTotal.toFixed(2)), energy_peaks_s: rep.audioInfo.peaks.map((p) => Number(p.t.toFixed(2))) },
    color: { avg_brightness_0_255: Math.round(rep.colorInfo.avgBrightness), overall_tone: rep.colorInfo.overallTone },
    aspect_ratio: rep.videoInfo.ratio,
    suggestions: rep.suggestions.map((s) => s.action),
  };
}

function triggerDownload(filename, mimeType, content) {
  try {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return true;
  } catch (e) {
    return false;
  }
}

function csvEscape(val) {
  const s = String(val ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function exportReportAsJSON(rep, fileName) {
  const summary = buildDataSummary(rep);
  const payload = { fileName, exportedAt: new Date().toISOString(), ...summary };
  return triggerDownload(`${(fileName || "cutscope-report").replace(/\.[^.]+$/, "")}.cutscope.json`, "application/json", JSON.stringify(payload, null, 2));
}

function exportReportAsCSV(rep, fileName) {
  const rows = [["section", "field", "value"]];
  rows.push(["summary", "file", fileName || ""]);
  rows.push(["summary", "duration_s", rep.duration.toFixed(2)]);
  rows.push(["summary", "overall_score", rep.score]);
  for (const c of rep.categories) rows.push(["category_score", c.label, c.score]);
  for (const i of rep.issues) rows.push(["issue", `${i.type} @ ${i.t.toFixed(2)}s (${i.severity})`, i.text]);
  for (const s of rep.shots) rows.push(["shot", `#${s.index} ${s.start.toFixed(2)}-${s.end.toFixed(2)}s`, `${s.lightLabel}, ${s.colorLabel}, ${s.length.toFixed(2)}s`]);
  rows.push(["audio", "avg_db", rep.audioInfo.avgDb.toFixed(1)]);
  rows.push(["audio", "dynamic_range_db", rep.audioInfo.dynamicRange.toFixed(1)]);
  rows.push(["audio", "total_silence_s", rep.audioInfo.silenceTotal.toFixed(2)]);
  rows.push(["color", "avg_brightness", Math.round(rep.colorInfo.avgBrightness)]);
  rows.push(["color", "overall_tone", rep.colorInfo.overallTone]);
  for (const s of rep.suggestions) rows.push(["suggestion", s.priority, s.action]);
  const csv = rows.map((r) => r.map(csvEscape).join(",")).join("\n");
  return triggerDownload(`${(fileName || "cutscope-report").replace(/\.[^.]+$/, "")}.cutscope.csv`, "text/csv", csv);
}

// ==================================================================
// NLE TIMELINE EXPORT (EDL / FCPXML)
//
// Honest limitations, stated once here rather than buried in comments
// throughout: the browser doesn't reliably expose the source video's real
// frame rate, so these exports use a frame rate YOU choose at export time
// (default 30fps) — if your actual footage is 24/25/60fps, pick that to
// keep timecodes accurate, or expect drift in the NLE if you don't.
// These also don't embed media — your NLE will ask you to relink the
// source file by name after import, which is normal for EDL/XML.
// ==================================================================

// Non-silent regions of the source, in original source-timeline
// coordinates. This is what actually gets "kept" in the exported timeline.
function computeKeepSegments(duration, silenceGaps) {
  const gaps = [...(silenceGaps || [])].sort((a, b) => a.start - b.start);
  const segments = [];
  let cursor = 0;
  for (const g of gaps) {
    if (g.start > cursor) segments.push({ start: cursor, end: g.start });
    cursor = Math.max(cursor, g.end);
  }
  if (cursor < duration) segments.push({ start: cursor, end: duration });
  return segments.filter((s) => s.end - s.start > 0.05);
}

// Maps a timestamp from the original (silence-included) source timeline
// into where it lands on the silence-stripped record timeline. Used so
// markers (cuts, audio peaks) land in the right place after silent
// sections are removed.
function mapToRecordTime(t, keepSegments) {
  let recordTime = 0;
  for (const seg of keepSegments) {
    if (t < seg.start) return recordTime; // fell inside a removed gap — snap to the following segment's start
    if (t <= seg.end) return recordTime + (t - seg.start);
    recordTime += seg.end - seg.start;
  }
  return recordTime; // past the end — clamp to total record duration
}

function secondsToTimecode(seconds, fps) {
  const totalFrames = Math.max(0, Math.round(seconds * fps));
  const ff = totalFrames % fps;
  const totalSeconds = Math.floor(totalFrames / fps);
  const ss = totalSeconds % 60;
  const mm = Math.floor(totalSeconds / 60) % 60;
  const hh = Math.floor(totalSeconds / 3600);
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(hh)}:${pad(mm)}:${pad(ss)}:${pad(ff)}`;
}

function generateEDL(rep, fileName, fps) {
  const keep = computeKeepSegments(rep.duration, rep.silenceGaps);
  const reelName = (fileName || "SOURCE").replace(/\.[^.]+$/, "").toUpperCase().slice(0, 8).padEnd(8, " ");
  let recordCursor = 0;
  const lines = [`TITLE: CutScope Export - ${fileName || "video"}`, "FCM: NON-DROP FRAME", ""];

  keep.forEach((seg, i) => {
    const num = String(i + 1).padStart(3, "0");
    const segDuration = seg.end - seg.start;
    const srcIn = secondsToTimecode(seg.start, fps);
    const srcOut = secondsToTimecode(seg.end, fps);
    const recIn = secondsToTimecode(recordCursor, fps);
    const recOut = secondsToTimecode(recordCursor + segDuration, fps);
    lines.push(`${num}  ${reelName} V     C        ${srcIn} ${srcOut} ${recIn} ${recOut}`);
    lines.push(`* FROM CLIP NAME: ${fileName || "video"}`);
    recordCursor += segDuration;
  });

  if (keep.length === 0) {
    lines.push("* NOTE: No non-silent segments detected — nothing to cut in.");
  } else {
    lines.push("", `* ${rep.silenceGaps.length} silent gap(s) removed, ${rep.duration.toFixed(2)}s -> ${recordCursor.toFixed(2)}s`);
  }

  for (const cut of rep.cuts) {
    const rt = mapToRecordTime(cut, keep);
    lines.push(`* MARKER: SCENE CUT @ ${secondsToTimecode(rt, fps)}`);
  }
  for (const peak of rep.audioInfo.peaks) {
    const rt = mapToRecordTime(peak.t, keep);
    lines.push(`* MARKER: AUDIO PEAK @ ${secondsToTimecode(rt, fps)}`);
  }

  return lines.join("\n");
}

function generateFCPXML(rep, fileName, fps) {
  const keep = computeKeepSegments(rep.duration, rep.silenceGaps);
  const frameDuration = `100/${fps * 100}s`;
  const toFrameTime = (seconds) => `${Math.round(seconds * fps)}/${fps}s`;
  const safeName = (fileName || "video").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  let recordCursor = 0;

  const clips = keep.map((seg) => {
    const dur = seg.end - seg.start;
    const clipXml = `        <asset-clip name="${safeName}" ref="r2" offset="${toFrameTime(recordCursor)}" duration="${toFrameTime(dur)}" start="${toFrameTime(seg.start)}"/>`;
    recordCursor += dur;
    return clipXml;
  }).join("\n");

  const cutMarkers = rep.cuts.map((cut) => {
    const rt = mapToRecordTime(cut, keep);
    return `        <marker start="${toFrameTime(rt)}" duration="${toFrameTime(1 / fps)}" value="Scene cut"/>`;
  }).join("\n");

  const peakMarkers = rep.audioInfo.peaks.map((peak) => {
    const rt = mapToRecordTime(peak.t, keep);
    return `        <marker start="${toFrameTime(rt)}" duration="${toFrameTime(1 / fps)}" value="Audio peak" completed="0"/>`;
  }).join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9">
  <resources>
    <format id="r1" name="FFVideoFormat1080p${fps}" frameDuration="${frameDuration}" width="1080" height="1920"/>
    <asset id="r2" name="${safeName}" src="file://./${safeName}" start="0s" duration="${toFrameTime(rep.duration)}" hasVideo="1" hasAudio="1" format="r1"/>
  </resources>
  <library>
    <event name="CutScope Export">
      <project name="${safeName} (silence removed)">
        <sequence format="r1" duration="${toFrameTime(recordCursor)}">
          <spine>
${clips}
${cutMarkers}
${peakMarkers}
          </spine>
        </sequence>
      </project>
    </event>
  </library>
</fcpxml>`;
}

function exportReportAsEDL(rep, fileName, fps) {
  const edl = generateEDL(rep, fileName, fps);
  return triggerDownload(`${(fileName || "cutscope").replace(/\.[^.]+$/, "")}.edl`, "text/plain", edl);
}

function exportReportAsFCPXML(rep, fileName, fps) {
  const xml = generateFCPXML(rep, fileName, fps);
  return triggerDownload(`${(fileName || "cutscope").replace(/\.[^.]+$/, "")}.fcpxml`, "application/xml", xml);
}

export default function CutScope() {
  const [stage, setStage] = useState("idle");
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState("");
  const [report, setReport] = useState(null);
  const [fileName, setFileName] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [isPro, setIsPro] = useState(false); // persistent, survives across videos/sessions once a real license verifies
  const [licenseKeyInput, setLicenseKeyInput] = useState("");
  const [licenseStatus, setLicenseStatus] = useState("idle"); // idle | checking | error
  const [licenseError, setLicenseError] = useState("");
  const [licenseLast4, setLicenseLast4] = useState("");
  const [thumbnail, setThumbnail] = useState(null);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [percentile, setPercentile] = useState(null);
  const [reviews, setReviews] = useState(SEED_REVIEWS);
  const [reviewText, setReviewText] = useState("");
  const [reviewName, setReviewName] = useState("");
  const [reviewCountry, setReviewCountry] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewStatus, setReviewStatus] = useState("");
  const [aiNotes, setAiNotes] = useState(null);
  const [aiStatus, setAiStatus] = useState("idle"); // idle | loading | done | error
  const [visionNotes, setVisionNotes] = useState(null);
  const [visionStatus, setVisionStatus] = useState("idle"); // idle | loading | done | error
  const [sampleFrames, setSampleFrames] = useState([]);
  const [chatMessages, setChatMessages] = useState([]); // {role: 'user'|'assistant', text}
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState("");
  const [exportFps, setExportFps] = useState(30);
  const [issueFilter, setIssueFilter] = useState("all");
  const [reportTab, setReportTab] = useState("diagnosis"); // "diagnosis" | "fixes" — splits the report into a diagnose-first view
  const [compareMode, setCompareMode] = useState(false);
  const [selectedForCompare, setSelectedForCompare] = useState([]);
  const [compareItems, setCompareItems] = useState(null); // [{fileName, thumbnail, report}, {...}] or null
  const [uploadQueue, setUploadQueue] = useState([]); // [{id, name, status: 'pending'|'analyzing'|'done'|'error'}]
  const [lastFile, setLastFile] = useState(null); // kept in memory so "re-analyze" doesn't need a re-upload
  const [noteTone, setNoteTone] = useState("coach"); // 'coach' | 'critic'
  const [previewUrl, setPreviewUrl] = useState(null); // live blob URL, only for the current video
  const [safeZonePlatform, setSafeZonePlatform] = useState("none"); // 'none'|'tiktok'|'reels'|'shorts'
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [hookHeatmap, setHookHeatmap] = useState(null);
  const previewVideoRef = useRef(null);
  const previewUrlRef = useRef(null);
  const [themeMode, setThemeMode] = useState("dark");
  // Real viewport tracking — the app had zero responsive behavior before this, so on a phone
  // the sidebar defaulting to open was reserving ~208px of a ~390px screen for every visitor.
  const [isMobile, setIsMobile] = useState(() => typeof window !== "undefined" && window.innerWidth <= 720);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 720px)");
    const handler = (e) => setIsMobile(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  const [sidebarOpen, setSidebarOpen] = useState(() => !(typeof window !== "undefined" && window.innerWidth <= 720));
  const [activePage, setActivePage] = useState("analyze");
  const [historyIndex, setHistoryIndex] = useState([]);
  const [historySearch, setHistorySearch] = useState("");
  const [historyLoading, setHistoryLoading] = useState(false);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [notifEnabled, setNotifEnabled] = useState(false);
  const fileInputRef = useRef(null);

  const toggleTheme = () => {
    const next = themeMode === "dark" ? "light" : "dark";
    Object.assign(COLORS, next === "dark" ? DARK : LIGHT);
    setThemeMode(next);
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await safeStorage.get("cutscope:settings", false);
        if (res && res.value) {
          const parsed = JSON.parse(res.value);
          setSettings({ ...DEFAULT_SETTINGS, ...parsed });
        }
      } catch (e) { /* keep defaults */ }
      try {
        const res2 = await safeStorage.get("cutscope:notif", false);
        if (res2 && res2.value) setNotifEnabled(res2.value === "true");
      } catch (e) { /* keep default */ }
    })();
  }, []);

  const updateSetting = (key, value) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    safeStorage.set("cutscope:settings", JSON.stringify(updated), false).catch(() => {});
  };

  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    safeStorage.set("cutscope:settings", JSON.stringify(DEFAULT_SETTINGS), false).catch(() => {});
  };

  const applyPreset = (values) => {
    const updated = { ...settings, ...values };
    setSettings(updated);
    safeStorage.set("cutscope:settings", JSON.stringify(updated), false).catch(() => {});
  };

  const toggleNotif = () => {
    const next = !notifEnabled;
    setNotifEnabled(next);
    safeStorage.set("cutscope:notif", String(next), false).catch(() => {});
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await safeStorage.get("cutscope:license:key", false);
        if (res && res.value) {
          setLicenseLast4(res.value.slice(-4));
          setIsPro(true); // trust the locally-stored result of a prior successful verification
        }
      } catch (e) { /* not licensed yet, that's the default */ }
    })();
  }, []);

  const checkLicense = useCallback(async (key) => {
    const trimmed = (key || "").trim();
    if (!trimmed) { setLicenseError("Enter the license key from your purchase email."); setLicenseStatus("error"); return; }
    setLicenseStatus("checking");
    setLicenseError("");
    try {
      const data = await verifyGumroadLicense(trimmed);
      if (data && data.success) {
        setIsPro(true);
        setLicenseLast4(trimmed.slice(-4));
        setLicenseStatus("idle");
        setLicenseKeyInput("");
        try { await safeStorage.set("cutscope:license:key", trimmed, false); } catch (e) { /* verified but couldn't persist locally — still unlocked for this session */ }
      } else {
        setLicenseError((data && data.message) || "That key wasn't recognized. Double-check it against your purchase email.");
        setLicenseStatus("error");
      }
    } catch (e) {
      setLicenseError("Couldn't reach the license server — check your connection and try again.");
      setLicenseStatus("error");
    }
  }, []);

  const removeLicense = useCallback(async () => {
    setIsPro(false);
    setLicenseLast4("");
    try { await safeStorage.delete("cutscope:license:key", false); } catch (e) { /* nothing stored, nothing to remove */ }
  }, []);

  const loadHistoryIndex = useCallback(async () => {
    try {
      const res = await safeStorage.get("cutscope:history:index", false);
      if (res && res.value) {
        const parsed = JSON.parse(res.value);
        if (Array.isArray(parsed)) { setHistoryIndex(parsed); return parsed; }
      }
    } catch (e) { /* no history yet */ }
    setHistoryIndex([]);
    return [];
  }, []);

  useEffect(() => { loadHistoryIndex(); }, [loadHistoryIndex]);

  const saveToHistory = useCallback(async (result, name, thumb, dup, pct) => {
    const id = `${Date.now()}`;
    const entry = { id, fileName: name, score: result.score, duration: result.duration, ts: Date.now(), thumb, tag: "" };
    try {
      await safeStorage.set(`cutscope:history:record:${id}`, JSON.stringify({
        report: result, fileName: name, thumbnail: thumb, duplicateInfo: dup, percentile: pct,
      }), false);
      const current = await loadHistoryIndex();
      const updated = [entry, ...current].slice(0, 100);
      await safeStorage.set("cutscope:history:index", JSON.stringify(updated), false);
      setHistoryIndex(updated);
    } catch (e) { /* history save failed silently, doesn't block the main flow */ }
  }, [loadHistoryIndex]);

  const setHistoryTag = useCallback(async (id, tag) => {
    setHistoryIndex((prev) => {
      const updated = prev.map((h) => (h.id === id ? { ...h, tag } : h));
      safeStorage.set("cutscope:history:index", JSON.stringify(updated), false).catch(() => {});
      return updated;
    });
  }, []);

  const deleteHistoryEntry = useCallback(async (id) => {
    try {
      await safeStorage.delete(`cutscope:history:record:${id}`, false).catch(() => null);
      const updated = historyIndex.filter((h) => h.id !== id);
      await safeStorage.set("cutscope:history:index", JSON.stringify(updated), false);
      setHistoryIndex(updated);
    } catch (e) { /* ignore */ }
  }, [historyIndex]);

  const reopenHistoryEntry = useCallback(async (id) => {
    setHistoryLoading(true);
    try {
      const res = await safeStorage.get(`cutscope:history:record:${id}`, false);
      if (res && res.value) {
        const data = JSON.parse(res.value);
        setReport(data.report);
        setFileName(data.fileName);
        setThumbnail(data.thumbnail);
        setDuplicateInfo(data.duplicateInfo || null);
        setPercentile(data.percentile != null ? data.percentile : null);
        setUnlocked(false);
        setStage("done");
        setActivePage("analyze");
        setAiNotes(null);
        setAiStatus("idle");
        // Sample frames aren't persisted to history (keeps saved records small),
        // so vision critique isn't available for reopened reports — the UI
        // reflects that with a disabled state rather than erroring on click.
        setVisionNotes(null);
        setVisionStatus("idle");
        setSampleFrames([]);
        setChatMessages([]);
        setChatError("");
        // Same limitation as sample frames: the source video/blob URL isn't
        // persisted to history, so live preview isn't available on reopen.
        revokePreview();
        setSafeZonePlatform("none");
        setShowHeatmap(false);
      }
    } catch (e) { /* ignore */ }
    setHistoryLoading(false);
  }, []);

  const toggleCompareMode = useCallback(() => {
    setCompareMode((m) => {
      if (m) setSelectedForCompare([]); // exiting compare mode clears selection
      return !m;
    });
  }, []);

  const toggleCompareSelect = useCallback((id) => {
    setSelectedForCompare((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 2) return prev;
      return [...prev, id];
    });
  }, []);

  const runCompare = useCallback(async () => {
    if (selectedForCompare.length !== 2) return;
    try {
      const results = await Promise.all(selectedForCompare.map(async (id) => {
        const res = await safeStorage.get(`cutscope:history:record:${id}`, false);
        if (!res || !res.value) return null;
        const data = JSON.parse(res.value);
        const indexEntry = historyIndex.find((h) => h.id === id);
        return { fileName: data.fileName, thumbnail: data.thumbnail, report: data.report, ts: indexEntry ? indexEntry.ts : 0 };
      }));
      if (results.every(Boolean)) {
        setCompareItems(results);
        setActivePage("compare");
      }
    } catch (e) { /* if it fails, just stay on History — nothing to break */ }
  }, [selectedForCompare, historyIndex]);

  const generateAINotes = useCallback(async (rep, tone) => {
    setAiStatus("loading");
    setAiNotes(null);
    try {
      const dataSummary = buildDataSummary(rep);
      const toneInstruction = tone === "critic"
        ? "Write in a blunt, no-fluff critic's voice — direct, a little impatient with sloppy technical mistakes, zero hedging. Still fair and specific, never insulting the person, just the execution."
        : "Write in an encouraging coach's voice — direct about what needs fixing, but framed constructively, acknowledging what's already working before listing fixes.";

      const prompt = `You are a professional short-form video editor reviewing measured technical data from a video (NOT the video itself — you cannot see it). Below is real, computer-measured data about cuts, audio levels, silence, and color. Do not invent visual details, story content, or anything not present in this data.

TONE: ${toneInstruction}

DATA:
${JSON.stringify(dataSummary, null, 2)}

Write "Editor's Notes" as a short, concrete checklist (6-10 items max) telling the editor exactly what technical edit to make and where, using the real timestamps given. Format each item as: "[timestamp] — action". Be specific and imperative ("Trim 0.4s from the shot at 3.20s–5.10s", "Normalize the level jump at 12.4s", "Re-export at 1080x1920 for 9:16"). Order by priority, most impactful first. Do not describe what happens on screen — you don't know that. End with one line rating how close this video is to short-form pacing best practices, based only on the scores given.`;

      const text = await callGeminiAPI({
        messages: [{ role: "user", text: prompt }],
        maxTokens: 1000,
      });
      setAiNotes(text);
      setAiStatus("done");
    } catch (e) {
      setAiStatus("error");
    }
  }, []);

  const generateVisionCritique = useCallback(async (frames) => {
    if (!frames || frames.length === 0) {
      setVisionStatus("error");
      return;
    }
    setVisionStatus("loading");
    setVisionNotes(null);
    try {
      const promptText = `These are ${frames.length} frames sampled evenly across a short-form video, in chronological order (roughly the start, two middle points, and near the end). You have not seen the rest of the video — only these still frames, no audio, no motion between them.

Give a short, honest visual critique (5-8 sentences) covering only what you can actually see:
- Composition and framing (is the subject clear, well-framed, centered appropriately for vertical video?)
- Visual variety across the frames (does it look like the same static shot the whole time, or does something change?)
- Any on-screen text — is it legible, well-placed, not cut off by UI overlays?
- Lighting/exposure as shown in these specific frames

Do not guess at story, dialogue, sound, or anything outside these images. Do not give a numeric "virality" score — describe honestly what a viewer would see, and end with one specific, actionable suggestion based only on what's visible.`;

      const text = await callGeminiAPI({
        messages: [{ role: "user", text: promptText }],
        images: frames.map((f) => f.dataUrl),
        maxTokens: 700,
      });
      setVisionNotes(text);
      setVisionStatus("done");
    } catch (e) {
      setVisionStatus("error");
    }
  }, []);

  const sendChatMessage = useCallback(async (rep, history, userText) => {
    const trimmed = userText.trim();
    if (!trimmed || chatLoading) return;

    const newUserMsg = { role: "user", text: trimmed };
    const updatedHistory = [...history, newUserMsg];
    setChatMessages(updatedHistory);
    setChatInput("");
    setChatLoading(true);
    setChatError("");

    try {
      const dataSummary = buildDataSummary(rep);
      const system = `You are CutScope's assistant, helping a video editor understand the results of an automated technical analysis of their short-form video. You have NOT watched the video — you only have the measured data below (real cut timestamps, audio levels, silence gaps, color/brightness). Never invent story, dialogue, or visual details beyond this data. If asked something this data can't answer (e.g. "is this funny", "will it go viral"), say plainly that you can't know that from the numbers you have, rather than guessing.

MEASURED DATA FOR THIS VIDEO:
${JSON.stringify(dataSummary, null, 2)}

Keep answers conversational and concise (2-5 sentences unless a checklist is genuinely needed). Reference exact timestamps from the data when relevant.`;

      const text = await callGeminiAPI({
        system,
        messages: updatedHistory,
        maxTokens: 600,
      });
      setChatMessages([...updatedHistory, { role: "assistant", text }]);
    } catch (e) {
      setChatError("Couldn't reach the AI service — try again in a moment.");
      setChatMessages(updatedHistory); // keep the user's message, just don't add a broken reply
    } finally {
      setChatLoading(false);
    }
  }, [chatLoading]);

  useEffect(() => {
    (async () => {
      try {
        const res = await safeStorage.get("cutscope:reviews", true);
        if (res && res.value) {
          const parsed = JSON.parse(res.value);
          if (Array.isArray(parsed) && parsed.length) setReviews(parsed);
        }
      } catch (e) { /* no reviews yet, keep seed */ }
    })();
  }, []);

  const recordAndRank = useCallback(async (file, score) => {
    let dup = null, pct = null;
    try {
      const hash = await hashFile(file);
      const key = `cutscope:hash:${hash}`;
      let existing = null;
      try { existing = await safeStorage.get(key, true); } catch (e) { existing = null; }
      if (existing && existing.value) {
        const data = JSON.parse(existing.value);
        dup = { seen: true, count: data.count + 1, firstScore: data.score };
        await safeStorage.set(key, JSON.stringify({ score: data.score, count: data.count + 1 }), true);
      } else {
        dup = { seen: false, count: 1 };
        await safeStorage.set(key, JSON.stringify({ score, count: 1 }), true);
      }
    } catch (e) { dup = { seen: false, count: 1, error: true }; }

    try {
      const listRes = await safeStorage.get("cutscope:scores", true).catch(() => null);
      let scores = [];
      if (listRes && listRes.value) { try { scores = JSON.parse(listRes.value); } catch (e) { scores = []; } }
      const below = scores.filter((s) => s <= score).length;
      pct = scores.length ? Math.round((below / scores.length) * 100) : 50;
      scores.push(score);
      if (scores.length > 300) scores = scores.slice(scores.length - 300);
      await safeStorage.set("cutscope:scores", JSON.stringify(scores), true);
    } catch (e) { pct = null; }

    setDuplicateInfo(dup);
    setPercentile(pct);
    return { dup, pct };
  }, []);

  const analysisIdRef = useRef(0);
  const activeUrlRef = useRef(null);
  const activeVideoRef = useRef(null);

  const revokePreview = useCallback(() => {
    if (previewUrlRef.current) { try { URL.revokeObjectURL(previewUrlRef.current); } catch (e) {} }
    previewUrlRef.current = null;
    setPreviewUrl(null);
    setHookHeatmap(null);
  }, []);

  // Revoke any lingering object URL / release the video element if the
  // component unmounts mid-analysis (prevents a blob URL memory leak).
  useEffect(() => {
    return () => {
      if (activeUrlRef.current) { try { URL.revokeObjectURL(activeUrlRef.current); } catch (e) {} }
      if (activeVideoRef.current) {
        try { activeVideoRef.current.pause(); activeVideoRef.current.removeAttribute("src"); activeVideoRef.current.load(); } catch (e) {}
      }
      if (previewUrlRef.current) { try { URL.revokeObjectURL(previewUrlRef.current); } catch (e) {} }
    };
  }, []);

  const runAnalysis = useCallback(async (file, onComplete) => {
    const finish = (success) => { if (typeof onComplete === "function") onComplete(success); };
    if (!file) { finish(false); return; }
    if (!file.type || !file.type.startsWith("video/")) {
      setErrorMsg("That doesn't look like a video file.");
      setStage("error");
      finish(false);
      return;
    }

    // Bump the run id so any in-flight previous analysis knows to abandon
    // its work instead of overwriting state with stale results (race guard).
    const myId = ++analysisIdRef.current;
    const isCancelled = () => analysisIdRef.current !== myId;

    revokePreview(); // starting fresh — release any prior video's preview URL
    setLastFile(file); // keep the File in memory so "re-analyze" can skip re-upload
    setStage("analyzing"); setProgress(0); setErrorMsg(""); setFileName(file.name); setUnlocked(false); setAiNotes(null); setAiStatus("idle"); setVisionNotes(null); setVisionStatus("idle"); setSampleFrames([]); setChatMessages([]); setChatError(""); setSafeZonePlatform("none"); setShowHeatmap(false); setIssueFilter("all");

    let url = null;
    let video = null;
    try {
      url = URL.createObjectURL(file);
      activeUrlRef.current = url;
      video = document.createElement("video");
      activeVideoRef.current = video;
      video.src = url; video.muted = true; video.playsInline = true; video.preload = "auto";
      setPhase("Reading video file");

      await new Promise((resolve, reject) => {
        const onLoaded = () => { cleanup(); resolve(); };
        const onError = () => { cleanup(); reject(new Error("Could not read this video file — it may be corrupted or in an unsupported format.")); };
        const timer = setTimeout(() => { cleanup(); reject(new Error("Timed out reading this video's metadata.")); }, 15000);
        const cleanup = () => {
          clearTimeout(timer);
          video.removeEventListener("loadedmetadata", onLoaded);
          video.removeEventListener("error", onError);
        };
        video.addEventListener("loadedmetadata", onLoaded, { once: true });
        video.addEventListener("error", onError, { once: true });
      });

      if (isCancelled()) { finish(false); return; }
      const duration = video.duration;
      if (!duration || !isFinite(duration) || duration <= 0) throw new Error("Could not determine video duration.");

      setPhase("Analyzing audio track");
      let windows = [];
      let hasAudio = true;
      try {
        windows = await analyzeAudio(file);
        if (windows.length === 0) hasAudio = false;
      } catch (audioErr) {
        // Audio analysis failing (e.g. no audio track, unsupported codec)
        // shouldn't block the rest of the report — degrade gracefully, but
        // say so honestly in the report rather than silently showing 0s.
        windows = [];
        hasAudio = false;
      }
      if (isCancelled()) { finish(false); return; }
      const silenceGaps = hasAudio ? detectSilence(windows, settings.silenceDb) : [];
      const jumps = hasAudio ? detectJumps(windows, settings.rmsJumpDb) : [];

      setPhase("Analyzing cuts, pacing & thumbnail");
      const cutsResult = await analyzeCutsAndThumbnail(video, duration, setProgress, settings.sceneThreshold, isCancelled);
      if (isCancelled() || !cutsResult) { finish(false); return; }
      const { cuts, thumbnailDataUrl, frames, sampleFrames: capturedFrames } = cutsResult;
      setThumbnail(thumbnailDataUrl);
      setSampleFrames(capturedFrames || []);

      setPhase("Reading hook-zone motion");
      let heatmapResult = null;
      try {
        heatmapResult = await computeHookHeatmap(video, duration, isCancelled);
      } catch (heatmapErr) {
        heatmapResult = null; // non-fatal — the rest of the report still works without it
      }
      if (isCancelled()) { finish(false); return; }

      setPhase("Generating report");
      const result = buildReport({
        duration, cuts, silenceGaps, jumps, windows,
        videoWidth: video.videoWidth, videoHeight: video.videoHeight, frames,
        hookWindow: settings.hookWindow, idealMaxShot: settings.idealMaxShot, hasAudio,
      });

      if (isCancelled()) { finish(false); return; }
      setReport(result);
      setStage("done");
      setHookHeatmap(heatmapResult);

      // Hand the object URL's ownership to the preview player instead of
      // letting the finally block revoke it — this is the one case where we
      // deliberately keep a blob URL alive past this function, so the user
      // can actually watch the video they just analyzed.
      previewUrlRef.current = url;
      setPreviewUrl(url);

      const { dup, pct } = await recordAndRank(file, result.score);
      if (isCancelled()) { finish(true); return; }
      saveToHistory(result, file.name, thumbnailDataUrl, dup, pct);
      finish(true);
    } catch (err) {
      if (!isCancelled()) {
        setErrorMsg((err && err.message) || "Something went wrong analyzing this video.");
        setStage("error");
      }
      finish(false);
    } finally {
      const isPreviewOwner = previewUrlRef.current === url;
      if (url && !isPreviewOwner) { try { URL.revokeObjectURL(url); } catch (e) {} }
      if (video) { try { video.pause(); video.removeAttribute("src"); video.load(); } catch (e) {} }
      if (activeUrlRef.current === url) activeUrlRef.current = null;
      if (activeVideoRef.current === video) activeVideoRef.current = null;
    }
  }, [recordAndRank, saveToHistory, settings, revokePreview]);


  const runQueue = useCallback(async (files) => {
    const items = files.map((f, i) => ({ id: `${Date.now()}-${i}`, name: f.name, status: "pending" }));
    setUploadQueue(items);
    for (let i = 0; i < files.length; i++) {
      setUploadQueue((q) => q.map((it, idx) => (idx === i ? { ...it, status: "analyzing" } : it)));
      const success = await new Promise((resolve) => {
        runAnalysis(files[i], resolve);
      });
      setUploadQueue((q) => q.map((it, idx) => (idx === i ? { ...it, status: success ? "done" : "error" } : it)));
    }
  }, [runAnalysis]);

  const handleFile = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 1) runAnalysis(files[0]);
    else if (files.length > 1) runQueue(files);
    if (e.target) e.target.value = ""; // allow re-selecting the same file(s) later
  };
  const handleDrop = (e) => {
    e.preventDefault(); setDragOver(false);
    const files = Array.from(e.dataTransfer?.files || []).filter((f) => f.type && f.type.startsWith("video/"));
    if (files.length === 1) runAnalysis(files[0]);
    else if (files.length > 1) runQueue(files);
    else if (e.dataTransfer?.files?.length) { setErrorMsg("That doesn't look like a video file."); setStage("error"); }
  };
  const reset = () => {
    analysisIdRef.current++; // invalidate any in-flight analysis
    revokePreview();
    setStage("idle"); setReport(null); setProgress(0); setFileName(""); setUnlocked(false);
    setThumbnail(null); setDuplicateInfo(null); setPercentile(null); setAiNotes(null); setAiStatus("idle"); setErrorMsg(""); setVisionNotes(null); setVisionStatus("idle"); setSampleFrames([]); setChatMessages([]); setChatError(""); setUploadQueue([]); setSafeZonePlatform("none"); setShowHeatmap(false); setIssueFilter("all");
  };

  const submitReview = async () => {
    if (!reviewText.trim()) return;
    const newReview = { name: reviewName.trim() || "Anonymous creator", country: reviewCountry.trim(), rating: reviewRating, text: reviewText.trim(), ts: Date.now() };
    const real = reviews.filter((r) => !r.isExample); // drop the placeholder once a real review exists
    const updated = [newReview, ...real].slice(0, 20);
    setReviews(updated);
    setReviewText(""); setReviewName(""); setReviewCountry(""); setReviewRating(5);
    setReviewStatus("Posted — thank you!");
    try { await safeStorage.set("cutscope:reviews", JSON.stringify(updated), true); }
    catch (e) { setReviewStatus("Saved locally (storage unavailable right now)."); }
    setTimeout(() => setReviewStatus(""), 3000);
  };

  const pageContent = activePage === "history" ? (
    <HistoryPage historyIndex={historyIndex} historySearch={historySearch} setHistorySearch={setHistorySearch}
      onDelete={deleteHistoryEntry} onReopen={reopenHistoryEntry} loading={historyLoading}
      compareMode={compareMode} selectedForCompare={selectedForCompare}
      onToggleCompareMode={toggleCompareMode} onToggleSelect={toggleCompareSelect} onCompareGo={runCompare} onSetTag={setHistoryTag} />
  ) : activePage === "compare" ? (
    <CompareView items={compareItems} onBack={() => setActivePage("history")} />
  ) : activePage === "pricing" ? (
    <PricingPage />
  ) : activePage === "terms" ? (
    <TermsPage />
  ) : activePage === "privacy" ? (
    <PrivacyPage />
  ) : activePage === "refund" ? (
    <RefundPage />
  ) : activePage === "settings" ? (
    <SettingsPage settings={settings} updateSetting={updateSetting} resetSettings={resetSettings} applyPreset={applyPreset}
      themeMode={themeMode} toggleTheme={toggleTheme} notifEnabled={notifEnabled} toggleNotif={toggleNotif}
      isPro={isPro} licenseLast4={licenseLast4} onRemoveLicense={removeLicense} />
  ) : activePage === "reviews" ? (
    <div style={{ maxWidth: 560, margin: "0 auto" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, color: COLORS.text }}>Reviews</h1>
        <p style={{ color: COLORS.muted, fontSize: 13.5, marginTop: 6 }}>Saved for everyone using this tool.</p>
      </div>
      <ReviewsSection reviews={reviews} reviewName={reviewName} setReviewName={setReviewName} reviewCountry={reviewCountry} setReviewCountry={setReviewCountry} reviewText={reviewText}
        setReviewText={setReviewText} reviewRating={reviewRating} setReviewRating={setReviewRating}
        submitReview={submitReview} reviewStatus={reviewStatus} />
    </div>
  ) : activePage !== "analyze" ? (
    <ComingSoon label={NAV_ITEMS.find((n) => n.key === activePage)?.label || ""} />
  ) : (
    <div style={{ maxWidth: 680, margin: "0 auto" }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, fontFamily: "ui-monospace, monospace", fontSize: 11, letterSpacing: 3, color: COLORS.cyan, textTransform: "uppercase", marginBottom: 10, background: `${COLORS.cyan}18`, padding: "4px 10px", borderRadius: 20 }}>
            <Film size={12} /> Free · runs in your browser
          </div>
          <h1 style={{ fontSize: isMobile ? 24 : 32, fontWeight: 900, letterSpacing: -1, margin: 0, lineHeight: 1.15, background: `linear-gradient(120deg, ${COLORS.text}, ${COLORS.cyan})`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>Find out what's actually hurting your video</h1>
          <p style={{ color: COLORS.muted, fontSize: 14.5, marginTop: 10, lineHeight: 1.6, maxWidth: 520 }}>
            Upload an edited video and get timestamped, specific fixes — not just a score. Nothing is uploaded anywhere except a fingerprint used for the duplicate check and score ranking.
          </p>
        </div>

        {stage === "idle" && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10, marginBottom: 28 }}>
              {HOW_IT_WORKS.map((s, i) => (
                <div key={i} style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "14px 14px" }}>
                  <div style={{ width: 26, height: 26, borderRadius: 7, marginBottom: 8, display: "flex", alignItems: "center", justifyContent: "center", background: `${COLORS.violet}22`, color: COLORS.violet }}><s.icon size={14} /></div>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: COLORS.text, marginBottom: 3 }}>{s.label}</div>
                  <div style={{ fontSize: 11, color: COLORS.muted, lineHeight: 1.4 }}>{s.desc}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 6, fontFamily: "ui-monospace, monospace" }}>PLATFORM (optional)</div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {Object.entries(PLATFORM_PRESETS).map(([key, preset]) => (
                    <button key={key} onClick={() => applyPreset(preset.values)} style={{
                      background: matchingPreset(settings) === key ? `${COLORS.violet}22` : "transparent",
                      color: matchingPreset(settings) === key ? COLORS.violet : COLORS.text,
                      border: `1px solid ${matchingPreset(settings) === key ? COLORS.violet : COLORS.panelBorder}`,
                      borderRadius: 14, padding: "5px 12px", fontSize: 11.5, cursor: "pointer",
                    }}>{preset.label}</button>
                  ))}
                </div>
              </div>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 6, fontFamily: "ui-monospace, monospace" }}>CONTENT TYPE (optional)</div>
                <select onChange={(e) => { if (e.target.value) applyPreset(CONTENT_TYPE_PRESETS[e.target.value].values); }} defaultValue=""
                  style={{ width: "100%", background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, padding: "7px 10px", color: COLORS.text, fontSize: 12.5, outline: "none" }}>
                  <option value="">Choose a format…</option>
                  {Object.entries(CONTENT_TYPE_PRESETS).map(([key, preset]) => (
                    <option key={key} value={key}>{preset.label}</option>
                  ))}
                </select>
              </div>
            </div>
            <div style={{ fontSize: 10.5, color: COLORS.muted, marginBottom: 20, lineHeight: 1.4 }}>
              These adjust pacing expectations before analysis — a cinematic video and a meme clip shouldn't be judged by the same shot-length bar. Reasonable starting points, not scientifically validated per-format rules. You can also fine-tune everything in Settings.
            </div>

            <div onDrop={handleDrop} onDragOver={(e) => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onClick={() => fileInputRef.current?.click()}
              style={{ border: `1.5px dashed ${dragOver ? COLORS.cyan : COLORS.panelBorder}`, borderRadius: 12, padding: "56px 24px", textAlign: "center", cursor: "pointer", background: dragOver ? `${COLORS.cyan}0F` : `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.sidebarBg})`, transition: "all 0.15s", marginBottom: 24 }}>
              <div style={{ width: 48, height: 48, borderRadius: 12, margin: "0 auto 16px", background: `${COLORS.violet}22`, display: "flex", alignItems: "center", justifyContent: "center", color: COLORS.violet }}><Upload size={22} /></div>
              <div style={{ fontSize: 16, marginBottom: 6, fontWeight: 600 }}>Drop videos here, or click to choose (one or several)</div>
              <div style={{ fontSize: 12, color: COLORS.muted, fontFamily: "ui-monospace, monospace" }}>MP4 · MOV · WEBM</div>
              <input ref={fileInputRef} type="file" accept="video/*" multiple onChange={handleFile} style={{ display: "none" }} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 32 }}>
              {CHECKS.map((c, i) => (
                <div key={i} style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "14px 16px", display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: `${COLORS.cyan}1F`, color: COLORS.cyan }}><c.icon size={15} /></div>
                  <div><div style={{ fontSize: 13, fontWeight: 700 }}>{c.label}</div><div style={{ fontSize: 11.5, color: COLORS.muted, marginTop: 2, lineHeight: 1.4 }}>{c.desc}</div></div>
                </div>
              ))}
            </div>
            <ReviewsSection reviews={reviews} reviewName={reviewName} setReviewName={setReviewName} reviewCountry={reviewCountry} setReviewCountry={setReviewCountry} reviewText={reviewText} setReviewText={setReviewText} reviewRating={reviewRating} setReviewRating={setReviewRating} submitReview={submitReview} reviewStatus={reviewStatus} />
          </>
        )}

        {stage === "analyzing" && (
          <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.sidebarBg})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 12, padding: 28 }}>
            <div style={{ fontSize: 13, color: COLORS.text, fontWeight: 700, marginBottom: 16 }}>Analyzing {fileName}…</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
              {ANALYSIS_STAGES.map((stageLabel, i) => {
                const currentIndex = ANALYSIS_STAGES.indexOf(phase);
                const isDone = currentIndex > i || (currentIndex === -1 && i === 0 && phase);
                const isActive = stageLabel === phase;
                return (
                  <div key={stageLabel} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, color: isActive ? COLORS.text : isDone ? COLORS.muted : COLORS.panelBorder }}>
                    {isDone ? <CheckCircle2 size={15} color={COLORS.green} /> :
                      isActive ? <div style={{ width: 15, height: 15, borderRadius: "50%", border: `2px solid ${COLORS.violet}`, borderTopColor: "transparent", animation: "spin 0.8s linear infinite" }} /> :
                      <div style={{ width: 15, height: 15, borderRadius: "50%", border: `2px solid ${COLORS.panelBorder}` }} />}
                    <span style={{ textDecoration: isDone ? "line-through" : "none" }}>{stageLabel}</span>
                  </div>
                );
              })}
            </div>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            <div style={{ height: 6, background: COLORS.panelBorder, borderRadius: 3, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${progress}%`, background: `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`, transition: "width 0.15s ease" }} />
            </div>

            {uploadQueue.length > 1 && (
              <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${COLORS.panelBorder}` }}>
                <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace", marginBottom: 10 }}>
                  Queue ({uploadQueue.filter((q) => q.status === "done").length}/{uploadQueue.length} done)
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {uploadQueue.map((item) => (
                    <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5 }}>
                      {item.status === "done" && <CheckCircle2 size={13} color={COLORS.green} />}
                      {item.status === "error" && <AlertTriangle size={13} color={COLORS.red} />}
                      {item.status === "analyzing" && <div style={{ width: 13, height: 13, borderRadius: "50%", border: `2px solid ${COLORS.violet}`, borderTopColor: "transparent", animation: "spin 0.8s linear infinite" }} />}
                      {item.status === "pending" && <div style={{ width: 13, height: 13, borderRadius: "50%", border: `2px solid ${COLORS.panelBorder}` }} />}
                      <span style={{ color: item.status === "pending" ? COLORS.muted : COLORS.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.name}</span>
                    </div>
                  ))}
                </div>
                <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
              </div>
            )}
          </div>
        )}

        {stage === "error" && (
          <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.red}`, borderRadius: 12, padding: 24 }}>
            <div style={{ color: COLORS.red, fontSize: 14, marginBottom: 12, display: "flex", gap: 8, alignItems: "center" }}><AlertTriangle size={16} /> {errorMsg}</div>
            <button onClick={reset} style={{ background: COLORS.panelBorder, color: COLORS.text, border: "none", borderRadius: 6, padding: "8px 16px", fontSize: 13, cursor: "pointer" }}>Try another file</button>
          </div>
        )}

        {stage === "done" && report && (
          <div>
            <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 14, padding: "24px 20px", marginBottom: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                <div style={{ fontSize: 12.5, fontFamily: "ui-monospace, monospace", color: COLORS.muted }}>{fileName} · {report.duration.toFixed(2)}s · {report.cutCount} cut{report.cutCount === 1 ? "" : "s"}</div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button onClick={() => exportReportAsJSON(report, fileName)} title="Export JSON" style={{ background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "5px 10px", fontSize: 11, cursor: "pointer", fontFamily: "ui-monospace, monospace" }}>JSON</button>
                  <button onClick={() => exportReportAsCSV(report, fileName)} title="Export CSV" style={{ background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "5px 10px", fontSize: 11, cursor: "pointer", fontFamily: "ui-monospace, monospace" }}>CSV</button>
                  <button onClick={() => lastFile && runAnalysis(lastFile)} title="Re-analyze this same file with current Settings sliders" style={{ background: "transparent", color: COLORS.violet, border: `1px solid ${COLORS.violet}55`, borderRadius: 6, padding: "5px 10px", fontSize: 11, cursor: "pointer", fontFamily: "ui-monospace, monospace", display: "flex", alignItems: "center", gap: 5 }}><RefreshCw size={11} /> Re-analyze</button>
                  <button onClick={reset} style={{ background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "5px 10px", fontSize: 11, cursor: "pointer", fontFamily: "ui-monospace, monospace", display: "flex", alignItems: "center", gap: 5 }}><RotateCcw size={11} /> New check</button>
                </div>
              </div>
              <Gauge score={report.score} />
              <ScoreDisclaimer />

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 10 }}>
                <div style={{ flex: 1, minWidth: 150, background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
                  <TrendingUp size={15} color={COLORS.cyan} />
                  <div style={{ fontSize: 12.5 }}>{percentile === null ? "Ranking…" : <>Better than <b>{percentile}%</b> of videos checked here</>}</div>
                </div>
                <div style={{ flex: 1, minWidth: 150, background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
                  <Copy size={15} color={duplicateInfo?.seen ? COLORS.amber : COLORS.green} />
                  <div style={{ fontSize: 12.5 }}>
                    {!duplicateInfo ? "Checking…" : duplicateInfo.seen ? <>Seen before — checked <b>{duplicateInfo.count}×</b></> : "New file — not seen before"}
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>{report.categories.map((cat) => <CategoryCard key={cat.key} cat={cat} />)}</div>
            </div>

            <HookAnalysisNote report={report} heatmap={hookHeatmap} hookWindow={settings.hookWindow} />

            <VideoInfoCard info={report.videoInfo} fileName={fileName} />

            <NLEExportCard report={report} fileName={fileName} fps={exportFps} setFps={setExportFps} onEDL={exportReportAsEDL} onFCPXML={exportReportAsFCPXML} />

            <VideoPreview url={previewUrl} videoRef={previewVideoRef}
              safeZonePlatform={safeZonePlatform} setSafeZonePlatform={setSafeZonePlatform}
              showHeatmap={showHeatmap} setShowHeatmap={setShowHeatmap}
              heatmap={hookHeatmap} frame0Db={report.windows[0]?.db} />

            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", marginBottom: 10, fontFamily: "ui-monospace, monospace" }}>Timeline {previewUrl && "· click a marker to jump the preview"}</div>
              {report.windows.length === 0 ? (
                <div style={{ height: 72, background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: COLORS.muted }}>
                  No audio waveform available for this file
                </div>
              ) : (
                <Waveform duration={report.duration} issues={report.issues} windows={report.windows} locked={!(unlocked || isPro)} silenceDb={settings.silenceDb}
                  onSeek={previewUrl ? (t) => { if (previewVideoRef.current) { previewVideoRef.current.currentTime = t; previewVideoRef.current.play().catch(() => {}); } } : null} />
              )}
            </div>

            <div style={{ display: "flex", gap: 6, marginBottom: 18, borderBottom: `1px solid ${COLORS.panelBorder}` }}>
              {[{ key: "diagnosis", label: "Diagnosis" }, { key: "fixes", label: "Fixes" }].map((t) => (
                <button key={t.key} onClick={() => setReportTab(t.key)} style={{
                  background: "none", border: "none", borderBottom: `2px solid ${reportTab === t.key ? COLORS.violet : "transparent"}`,
                  color: reportTab === t.key ? COLORS.violet : COLORS.muted, fontWeight: reportTab === t.key ? 700 : 500,
                  fontSize: 13.5, padding: "8px 4px", marginRight: 18, cursor: "pointer",
                }}>{t.label}</button>
              ))}
            </div>

            {!(unlocked || isPro) ? (
              <div style={{ background: `linear-gradient(160deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${COLORS.violet}`, borderRadius: 12, padding: 24, textAlign: "center" }}>
                <Lock size={20} color={COLORS.violet} style={{ marginBottom: 8 }} />
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{report.issues.length} issue{report.issues.length === 1 ? "" : "s"} found</div>
                <div style={{ fontSize: 13, color: COLORS.muted, marginBottom: 18, lineHeight: 1.5 }}>Unlock the full report to see exact timestamps, fixes, and the suggested thumbnail frame.</div>

                <a href={GUMROAD_PRODUCT_URL} target="_blank" rel="noopener noreferrer" style={{
                  display: "inline-block", background: `linear-gradient(90deg, ${COLORS.violet}, ${COLORS.cyan})`, color: "#0F0B1E",
                  border: "none", borderRadius: 8, padding: "10px 22px", fontSize: 13.5, fontWeight: 700, textDecoration: "none", marginBottom: 16,
                }}>Buy for ${PRICING.price} once →</a>

                <div style={{ maxWidth: 320, margin: "0 auto", textAlign: "left" }}>
                  <div style={{ fontSize: 11.5, color: COLORS.muted, marginBottom: 6 }}>Already bought it? Enter your license key from the purchase email:</div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <input value={licenseKeyInput} onChange={(e) => setLicenseKeyInput(e.target.value)} placeholder="XXXX-XXXX-XXXX-XXXX"
                      disabled={licenseStatus === "checking"}
                      style={{ flex: 1, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "7px 10px", color: COLORS.text, fontSize: 12.5, outline: "none" }} />
                    <button onClick={() => checkLicense(licenseKeyInput)} disabled={licenseStatus === "checking"} style={{
                      background: COLORS.panelBorder, color: COLORS.text, border: "none", borderRadius: 6, padding: "7px 14px",
                      fontSize: 12, fontWeight: 700, cursor: licenseStatus === "checking" ? "default" : "pointer",
                    }}>{licenseStatus === "checking" ? "…" : "Verify"}</button>
                  </div>
                  {licenseStatus === "error" && <div style={{ fontSize: 11, color: COLORS.red, marginTop: 6 }}>{licenseError}</div>}
                </div>

              </div>
            ) : (
              <>
                {isPro && !unlocked && (
                  <div style={{ fontSize: 11, color: COLORS.green, marginBottom: 14, display: "flex", alignItems: "center", gap: 6 }}>
                    <CheckCircle2 size={13} /> Unlocked with your license {licenseLast4 && `(ending ${licenseLast4})`}
                  </div>
                )}
                {reportTab === "diagnosis" ? (
                  <>
                    <ShotTable shots={report.shots} />
                    <AudioInfoCard audioInfo={report.audioInfo} />
                    <ColorInfoCard colorInfo={report.colorInfo} />
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
                        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", fontFamily: "ui-monospace, monospace" }}>
                          {report.issues.length} issue{report.issues.length === 1 ? "" : "s"} found
                        </div>
                        {report.issues.length > 0 && (
                          <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                            {["all", "hook", "pacing", "silence", "audio", "platform"].map((f) => {
                              const count = f === "all" ? report.issues.length : report.issues.filter((i) => i.type === f).length;
                              if (f !== "all" && count === 0) return null;
                              return (
                                <button key={f} onClick={() => setIssueFilter(f)} style={{
                                  background: issueFilter === f ? `${COLORS.violet}22` : "transparent",
                                  color: issueFilter === f ? COLORS.violet : COLORS.muted,
                                  border: `1px solid ${issueFilter === f ? COLORS.violet : COLORS.panelBorder}`,
                                  borderRadius: 12, padding: "3px 10px", fontSize: 10.5, cursor: "pointer", textTransform: "capitalize",
                                }}>{f} {f !== "all" && `(${count})`}</button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                      {report.issues.length === 0 ? (
                        <div style={{ color: COLORS.green, fontSize: 14, padding: "16px 0", display: "flex", alignItems: "center", gap: 8 }}><CheckCircle2 size={18} /> Nothing flagged against current benchmarks.</div>
                      ) : (
                        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                          {report.issues.filter((issue) => issueFilter === "all" || issue.type === issueFilter).map((issue, i) => <IssueCard key={i} issue={issue} />)}
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    {thumbnail && (
                      <div style={{ marginBottom: 20 }}>
                        <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", marginBottom: 10, fontFamily: "ui-monospace, monospace", display: "flex", alignItems: "center", gap: 6 }}><ImageIcon size={12} /> Suggested thumbnail frame</div>
                        <img src={thumbnail} alt="Suggested thumbnail" style={{ borderRadius: 10, border: `1px solid ${COLORS.panelBorder}`, maxWidth: 220, display: "block" }} />
                      </div>
                    )}
                    {AI_FEATURES_ENABLED ? (
                      <>
                        <ChatCard messages={chatMessages} input={chatInput} setInput={setChatInput} loading={chatLoading} error={chatError}
                          onSend={(text) => sendChatMessage(report, chatMessages, text)} />
                        <VisionCritiqueCard status={visionStatus} notes={visionNotes} onGenerate={() => generateVisionCritique(sampleFrames)} frames={sampleFrames} />
                        <AIEditorCard status={aiStatus} notes={aiNotes} onGenerate={() => generateAINotes(report, noteTone)} tone={noteTone} setTone={setNoteTone} />
                      </>
                    ) : (
                      <>
                        <AIFeatureDisabledNotice title="Ask about this video (AI chat)" icon={Sparkles} />
                        <AIFeatureDisabledNotice title="Visual content critique" icon={ImageIcon} />
                        <AIFeatureDisabledNotice title="AI editor notes" icon={Sparkles} />
                      </>
                    )}
                    <SuggestionsCard suggestions={report.suggestions} />
                    <PlaybookCard />
                  </>
                )}
              </>
            )}

            <div style={{ marginTop: 32 }}>
              <ReviewsSection reviews={reviews} reviewName={reviewName} setReviewName={setReviewName} reviewCountry={reviewCountry} setReviewCountry={setReviewCountry} reviewText={reviewText} setReviewText={setReviewText} reviewRating={reviewRating} setReviewRating={setReviewRating} submitReview={submitReview} reviewStatus={reviewStatus} />
            </div>
          </div>
        )}
    </div>
  );

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: COLORS.bgGradB, fontFamily: "ui-sans-serif, system-ui, -apple-system, sans-serif" }}>
      <style>{`
        input:focus-visible, textarea:focus-visible, select:focus-visible, button:focus-visible, [tabindex]:focus-visible {
          outline: 2px solid ${COLORS.violet} !important;
          outline-offset: 2px !important;
        }
      `}</style>
      <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} activePage={activePage} setActivePage={setActivePage} isMobile={isMobile} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <Topbar themeMode={themeMode} toggleTheme={toggleTheme} setActivePage={setActivePage} />
        <div style={{ background: `radial-gradient(circle at 20% 0%, ${COLORS.bgGradA}, ${COLORS.bgGradB} 60%)`, color: COLORS.text, minHeight: "calc(100vh - 56px)", padding: isMobile ? "20px 14px" : "32px 24px" }}>
          {pageContent}
        </div>
      </div>
    </div>
  );
}

function ReviewsSection({ reviews, reviewName, setReviewName, reviewCountry, setReviewCountry, reviewText, setReviewText, reviewRating, setReviewRating, submitReview, reviewStatus }) {
  return (
    <div>
      <div style={{ fontSize: 11, letterSpacing: 2, color: COLORS.muted, textTransform: "uppercase", marginBottom: 10, fontFamily: "ui-monospace, monospace" }}>What creators are saying</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
        {reviews.slice(0, 6).map((r, i) => (
          <div key={i} style={{ background: `linear-gradient(135deg, ${COLORS.panel}, ${COLORS.panelAlt})`, border: `1px solid ${r.isExample ? COLORS.panelBorder : COLORS.panelBorder}`, borderRadius: 8, padding: "12px 14px", opacity: r.isExample ? 0.7 : 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <div style={{ fontSize: 13, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}>
                {r.name}{r.country ? ` · ${r.country}` : ""}
                {r.isExample && <span style={{ fontSize: 9.5, fontWeight: 600, color: COLORS.muted, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 8, padding: "1px 6px", textTransform: "uppercase" }}>Example</span>}
              </div>
              <Stars value={r.rating} />
            </div>
            <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.5 }}>{r.text}</div>
          </div>
        ))}
      </div>
      <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 10, padding: 16 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 10 }}>Leave a review</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 8, flexWrap: "wrap" }}>
          <input value={reviewName} onChange={(e) => setReviewName(e.target.value)} placeholder="Name (optional)"
            style={{ flex: "1 1 100px", minWidth: 0, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "8px 10px", color: COLORS.text, fontSize: 12.5, outline: "none" }} />
          <input value={reviewCountry} onChange={(e) => setReviewCountry(e.target.value)} placeholder="Country (optional)"
            style={{ flex: "1 1 100px", minWidth: 0, background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "8px 10px", color: COLORS.text, fontSize: 12.5, outline: "none" }} />
          <Stars value={reviewRating} onChange={setReviewRating} />
        </div>
        <textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} placeholder="What did you think?" rows={2}
          style={{ width: "100%", background: COLORS.inputBg, border: `1px solid ${COLORS.panelBorder}`, borderRadius: 6, padding: "8px 10px", color: COLORS.text, fontSize: 12.5, outline: "none", resize: "vertical", boxSizing: "border-box", marginBottom: 8 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={submitReview} style={{ background: COLORS.violet, color: "#fff", border: "none", borderRadius: 6, padding: "7px 14px", fontSize: 12.5, cursor: "pointer", fontWeight: 700 }}>Post review</button>
          {reviewStatus && <div style={{ fontSize: 11.5, color: COLORS.green }}>{reviewStatus}</div>}
        </div>
      </div>
    </div>
  );
}
