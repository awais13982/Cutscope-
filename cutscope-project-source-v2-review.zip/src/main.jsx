import React from 'react'
import ReactDOM from 'react-dom/client'
import CutScope from './CutScope.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CutScope />
  </React.StrictMode>,
)
