// netlify/functions/anthropic-proxy.js
//
// This is the piece that fixes the #1 critical security gap: the frontend
// never sees or holds the real Anthropic API key. It sends its request here
// instead, this function attaches the real key (from a Netlify environment
// variable, never committed to code), forwards it to Anthropic, and passes
// the response back.
//
// SETUP (one-time, in the Netlify dashboard, not in code):
// 1. Get an API key from console.anthropic.com
// 2. In Netlify: Site settings -> Environment variables -> add
//    ANTHROPIC_API_KEY = your real key
// 3. Redeploy. That's it — this function will pick it up automatically.

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: "Server isn't configured yet — ANTHROPIC_API_KEY is missing in Netlify's environment variables." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: "Invalid request body" }), { status: 400 });
  }

  // Basic guardrails so this proxy can't be trivially abused to run
  // arbitrary huge/unrelated requests against your API key.
  const ALLOWED_MODELS = ["claude-sonnet-4-6"];
  if (!ALLOWED_MODELS.includes(body.model)) {
    return new Response(JSON.stringify({ error: "Model not allowed" }), { status: 400 });
  }
  if (typeof body.max_tokens !== "number" || body.max_tokens > 1200) {
    return new Response(JSON.stringify({ error: "max_tokens too high or missing" }), { status: 400 });
  }

  try {
    const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
    });

    const data = await anthropicResponse.text();
    return new Response(data, {
      status: anthropicResponse.status,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Couldn't reach Anthropic's API" }), { status: 502 });
  }
};

export const config = {
  path: "/api/anthropic",
};
