// netlify/functions/gemini-proxy.js
//
// Proxies AI requests to Google's Gemini API (free tier) so the real API
// key never sits in browser-visible code. The frontend sends a simplified
// payload here; this function attaches the real key (from a Netlify
// environment variable) and forwards to Google.
//
// SETUP (one-time, in the Netlify dashboard, not in code):
// 1. Get a free API key at aistudio.google.com/apikey (no credit card required)
// 2. In Netlify: Site settings -> Environment variables -> add
//    GEMINI_API_KEY = your real key
// 3. Redeploy. That's it.
//
// HONEST NOTE ON PRIVACY: Google's free Gemini tier may use submitted data
// to improve their models for users outside the EU/UK/EEA. This is
// different from a paid API key, which typically isn't used for training.
// CutScope's Privacy Policy discloses this — don't quietly change providers
// without updating that page to match reality.

const GEMINI_MODEL = "gemini-2.5-flash";

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: "Server isn't configured yet — GEMINI_API_KEY is missing in Netlify's environment variables." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: "Invalid request body" }), { status: 400 });
  }

  // Basic guardrails so this proxy can't be trivially abused to burn
  // through the free quota on unrelated requests.
  const maxTokens = body.generationConfig && body.generationConfig.maxOutputTokens;
  if (typeof maxTokens !== "number" || maxTokens > 1200) {
    return new Response(JSON.stringify({ error: "maxOutputTokens too high or missing" }), { status: 400 });
  }
  if (!Array.isArray(body.contents)) {
    return new Response(JSON.stringify({ error: "Missing contents array" }), { status: 400 });
  }

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;
    const geminiResponse = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const data = await geminiResponse.text();
    return new Response(data, {
      status: geminiResponse.status,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Couldn't reach Gemini's API" }), { status: 502 });
  }
};

export const config = {
  path: "/api/gemini",
};
